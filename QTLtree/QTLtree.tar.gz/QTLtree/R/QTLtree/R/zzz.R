
.First.lib <- function(lib, pkg) {
  library.dynam("ijwtools", pkg, lib)
}
