
#ifndef NEWICK_H
#define NEWICK_H
#include "node.h"
void write_Newick(node *root, char *filename, int *info);
#endif
