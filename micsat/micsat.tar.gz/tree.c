#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include "utils.h" 
#include "time.h"
#include "tree.h"
#include "random.h"
#include "node.h"
#include "prior.h"

void destroy_tree(tree *any)
{
    int i;
    for (i=1;i<2*any->SS;i++) 
	free_ivector(any->sample[i].genotype,1,any->NLOC);
    free(any->sample);  
}
/***************************************************************************/
int getdistance(int *g1,int *g2, int nloc)
{
    int d=0;
    int i;

    for (i=1;i<=nloc;i++) 
        if ((g1[i]>=0)&&(g2[i]>=0))
            d += abs(g1[i]-g2[i]);

    return d;
}
/***************************************************************************/    
int *gethap(int *g1,int *g2, int nloc, double bs)
{
    int i,*newhap;
    double mean,sd,mini,maxi;
 
    newhap=ivector(1,nloc);
    for (i=1;i<=nloc;i++) {   
        if (g1[i]<0 && g2[i]<0) {
            g1[i] = 3;
            g2[i] = 3;
        }
        else if (g1[i]<0) {
            g1[i] = (int)rint((double)g2[i] + bs*normal());
            if (g1[i]<0) g1[i]=0;
        }
        else if (g2[i]<0) {
            g2[i] = (int)rint((double)g1[i] + bs*normal());
            if (g2[i]<0) g2[i]=0;
        }

        if (g1[i]<g2[i]) {
            mini=(double)g1[i];
            maxi=(double)g2[i];
        }
        else {
            mini=(double)g1[i];
            maxi=(double)g2[i];
        }       
        mean = (mini+maxi)/2.0;
        sd = (maxi-mini+10.*bs)/4.0;
        newhap[i] = (int)rint(mean + sd*normal());
        if (newhap[i]<0) newhap[i] = 0;
    }
    return newhap;
}   

/***************************************************************************/     
void get_next_joins(int **gensleft,int nleft, int *j1,int *j2,
     int nloc,double bs)
{
    double *dis;
    int i,j,d,dmin=1000,cmin=0,which;

    if (nleft==2)
    {
	*j1=1;
	*j2=2;
	return;
    }

    if (bs >= 1.0) {
        *j1 = 1+(int)(ranDum()*(double)(nleft-1));
        *j2 = 1+(int)(ranDum()*(double)(nleft-1));
        if (*j2 >= *j1) *j2 +=1;
        return;
    }
    else if (bs<=0.0) {
        for (i=1;i<nleft;i++)
            for (j=i+1;j<=nleft;j++) {
                d = getdistance(gensleft[i],gensleft[j],nloc);
                if (d==dmin) cmin +=1 ;
                else if (d<dmin) {
                    dmin=d;
                    cmin=1;
                }
            }
        if (cmin==1) which=1;
        else which=1+(int)(ranDum()*(double)cmin);
        cmin=0;
        for (i=1;i<nleft;i++)
            for (j=i+1;j<=nleft;j++) {
                d = getdistance(gensleft[i],gensleft[j],nloc);
                if (d==dmin) cmin +=1 ;
                if (cmin==which) {
                   *j1 = i;
                   *j2 = j;
                    return;
                }
             }
        myerror("should not get this far in get_next_joins");
        return;        
    }
    else {
        cmin=1;
        dis = dvector(1,nleft*(nleft-1)/2);
        for (i=1;i<nleft;i++) {
            for (j=i+1;j<=nleft;j++) {
                d = getdistance(gensleft[i],gensleft[j],nloc);
                dis[cmin++] = 1./(10.*bs+(double)d);
            }
        }
        cmin-=1;
	if (cmin != nleft*(nleft-1)/2)
	    myerror("error in get_next_joins");
	which = gen_from_probs(dis,cmin);
	if (which > cmin) myerror("error 5 in get_next ...");
	if (which < 1) myerror("error 6 in get_next ...");
        cmin=0;
	*j1=*j2=0;
	for (i=1;i<nleft;i++) {
            for (j=i+1;j<=nleft;j++) {
               cmin+=1;
               if (cmin==which) {
                   *j1=i;
                   *j2 = j;
               }
            }
        }
	free_dvector(dis,1,nleft*(nleft-1)/2);
	if ((*j1>0)&&(*j2>0))
                   return;
	else 
        myerror("should not get this far in get_next_joins");
       
    }
}
/***************************************************************************/
/*  Get a starting tree based on genotype badness = 0 gives parsimony      */
/*  and badness =1 gives complete randomness - in between ....             */
/*  The priors and likelihoods have to be calculated somewhere else ....   */
/***************************************************************************/
#define DO_LOCUS_LOOP for (locus=1;locus<=temp.NLOC;locus++)
tree starting_tree(int **genotype, int samplesize, int nloc,double badness)
{
    tree temp;
    int i,which,tojoin;
    node **whichnode;
    double t=0.0,n_left,add,totlength=0.0;  

    temp.SS =samplesize;
    temp.NLOC=nloc;
   
    whichnode = (node **)malloc((samplesize+1)*sizeof(node *));
    if (!whichnode) myerror("error allocating whichnode");

    temp.sample = (node *)malloc((2*temp.SS)*sizeof(node));
    if (!temp.sample) myerror("error allocating root");
    temp.root = &(temp.sample[2*temp.SS-1]);
    temp.ancestors=&(temp.sample[temp.SS]);

    for (i=1;i<=samplesize;i++) {
        temp.sample[i].descendent1=NULL;
        temp.sample[i].descendent2=NULL;
	temp.sample[i].ancestor=NULL;
	temp.sample[i].next=NULL;
	temp.sample[i].prev=NULL;
        temp.sample[i].genotype=genotype[i];
        temp.sample[i].time=0.0;
        whichnode[i] = &(temp.sample[i]);
    }
 
    for (i=1;i<=samplesize-1;i++) {
        n_left = (double)(samplesize+1-i);
        add = -log(ranDum())*2.0/(n_left*(n_left-1.0));
        t+=add;
	totlength+=add*n_left;


	get_next_joins(genotype,samplesize+1-i,&which,&tojoin,nloc,badness);

        temp.ancestors[i].time = t;
        temp.ancestors[i].descendent1=whichnode[which];
        temp.ancestors[i].descendent2=whichnode[tojoin];

        temp.ancestors[i].genotype=
              gethap(genotype[which],genotype[tojoin],nloc,badness);
 
        whichnode[tojoin]->ancestor=&(temp.ancestors[i]);
        whichnode[which]->ancestor=&(temp.ancestors[i]);
        whichnode[tojoin]=&(temp.ancestors[i]);
        whichnode[which] = whichnode[samplesize+1-i];
        genotype[tojoin]=temp.ancestors[i].genotype;
        genotype[which]=genotype[samplesize+1-i];
     }
    free(whichnode);
    temp.first=&(temp.ancestors[1]);
    for (i=1;i<=samplesize-2;i++) {
    	temp.ancestors[i].prev=&(temp.ancestors[i-1]);
	temp.ancestors[i].next=&(temp.ancestors[i+1]);
    }
    temp.first->prev->next=temp.first;
    temp.root->prev=&(temp.ancestors[samplesize-2]);
    temp.root->next=NULL;
    temp.root->ancestor=NULL; 
    temp.totallength=totlength;
    return temp;
} 
/***************************************************************************/   
  
