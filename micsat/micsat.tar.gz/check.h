#ifndef CHECK_H
#define CHECK_H
void checktree(tree *anytree, char message[]);
#endif
