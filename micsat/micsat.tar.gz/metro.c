/* Metropolis Hasting's for changing mu, N and the 
 * times within the tree (without changing tree shape  */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "metro.h"
#include "random.h"
#include "lhood.h"
#include "prior.h"
#include "time.h"
#include "utils.h"
#ifdef CHECK
#include "check.h"
#endif

#define DO_LOCUS_LOOP for (locus=1;locus<=any->NLOC;locus++)
/************************************************************************/
/*   The metropolis function for moving between values of mu            */
/************************************************************************/
int metro_mu(tree *any,double tune) 
{   
    double newmu,newtheta,x;
    lltype candllmut;

    newmu = any->mu + tune*normal();
    if (newmu<0.0) newmu=-newmu;
    newtheta = 2.0*newmu*any->N;
    candllmut = loglikelihoodtheta(any,newtheta);

    x= exp(candllmut+log_prior(&newmu,any->MUPRIOR)-
	    any->llmut-log_prior(&any->mu,any->MUPRIOR));

    if ((x>1.0)||(ranDum()<x)) {
	any->theta = newtheta;
	any->mu = newmu;
	any->llmut = candllmut;
#ifdef CHECK
	checktree(any,"after metro_mu");
#endif
	return 1;
    }
    loglikelihoodtheta(any,any->theta);
    return 0;
}

/************************************************************************/
/*   The metropolis function for moving between values of N             */
/************************************************************************/
int metro_N(tree *any,double tune) 
{   
    double newN,x,newtheta;
    lltype candllmut;

    newN=any->N+tune*normal();
    if (newN<0.0) newN=-newN;
    newtheta = 2.0*any->mu*newN;
    candllmut=loglikelihoodtheta(any,newtheta);

    x= exp(candllmut+ log_prior(&newN,any->NPRIOR)- any->llmut-
	    log_prior(&(any->N),any->NPRIOR));
    if ((x>1.0)||(ranDum()<x)) {
	any->theta = newtheta;
	any->N = newN;
	any->llmut = candllmut;
#ifdef CHECK
	checktree(any,"after metro_N");
#endif
	return 1;
    }
    loglikelihoodtheta(any,any->theta); 
    return 0;
}
/************************************************************************/
int metro_times(tree *any) 
{   
    double difflltimes,diffllmut,mintime,lprob,ll[3];
    double newtime,x;
    int which;
    node *whichnode,*here;

    which = (int)(ranDum()*(double)(any->SS-1))+1;
    whichnode = &(any->ancestors[which]);

    if (whichnode->descendent1->time>whichnode->descendent2->time)
	mintime=whichnode->descendent1->time;
    else mintime=whichnode->descendent2->time;

    if (whichnode->ancestor!=NULL) {	
	if (whichnode->ancestor->descendent1!=whichnode) 
	    nodeswap(whichnode->ancestor);
	newtime = mintime+ranDum()*(whichnode->ancestor->time-mintime);
	ll[0]=ll_mut(whichnode->descendent1->genotype,whichnode->genotype,  
		newtime-whichnode->descendent1->time,any->theta,any->NLOC);
	diffllmut = ll[0]-whichnode->ll_left;
	ll[1]=ll_mut(whichnode->descendent2->genotype,whichnode->genotype,  
		newtime-whichnode->descendent2->time,any->theta,any->NLOC);
	diffllmut += ll[1]-whichnode->ll_right;
	ll[2]=ll_mut(whichnode->genotype,whichnode->ancestor->genotype,  
		whichnode->ancestor->time-newtime,any->theta,any->NLOC);
	diffllmut += ll[2]-whichnode->ancestor->ll_left;

	lprob=0.0;
    }
    else {
	newtime = mintime - log(ranDum());
	ll[0]=ll_mut(whichnode->descendent1->genotype,whichnode->genotype,  
		newtime-whichnode->descendent1->time,any->theta,any->NLOC);
	diffllmut = ll[0] - whichnode->ll_left;
	ll[1]=ll_mut(whichnode->descendent2->genotype,whichnode->genotype,  
		newtime-whichnode->descendent2->time,any->theta,any->NLOC);

	diffllmut += ll[1]-whichnode->ll_right;
	lprob = -whichnode->time+newtime;
    }
    
    here = difflltcj(&difflltimes,any->first,whichnode,newtime,any->info);
    x= exp(diffllmut+lprob+difflltimes);

    if ((x>1.0)||(ranDum()<x)) {
	any->llmut += diffllmut;
	any->lltimes+=difflltimes;
	whichnode->ll_left=ll[0];
	whichnode->ll_right=ll[1];
	if (whichnode->ancestor!=NULL) {
	    any->totallength+=newtime-whichnode->time;
	    whichnode->ancestor->ll_left=ll[2];
	}
	else any->totallength += 2.*(newtime-whichnode->time);
	any->first=remaketimes(any->first,here,whichnode,newtime);
#ifdef CHECK	
	checktree(any,"within metro_times");
#endif
	return 1;
    }
    return 0;
}
/*************************************************************************/
int metro_haplotype(tree *any) 
{   
    double diffllmut,ll[3],x;
    int which,whichlocus,i;
    node *whichnode;
    int *newhap;

    newhap = ivector(1,any->NLOC);   

    which = 1+ (int)(ranDum()*(double)(any->SS-1));
    whichnode = &(any->ancestors[which]);
    whichlocus=1+(int)(ranDum()*(double)(any->NLOC));

    for (i=1;i<=any->NLOC;i++) newhap[i]=whichnode->genotype[i];
    if (ranDum()<0.5) newhap[whichlocus] += 1;
    else newhap[whichlocus]-=1;   

    if (whichnode->ancestor!=NULL) {
	if (whichnode->ancestor->descendent1!=whichnode) 
	    nodeswap(whichnode->ancestor);

	ll[0]=ll_mut(whichnode->descendent1->genotype,newhap,whichnode->time
		-whichnode->descendent1->time,any->theta,any->NLOC);
	diffllmut = ll[0]-whichnode->ll_left;

	ll[1]=ll_mut(whichnode->descendent2->genotype,newhap,whichnode->time
		-whichnode->descendent2->time,any->theta,any->NLOC);
	diffllmut += ll[1]-whichnode->ll_right;

	ll[2]=ll_mut(newhap,whichnode->ancestor->genotype,
		whichnode->ancestor->time-whichnode->time,any->theta,any->NLOC);
	diffllmut += ll[2] - whichnode->ancestor->ll_left;	
    }
    else {
	ll[0]=ll_mut(whichnode->descendent1->genotype,newhap,whichnode->time
		-whichnode->descendent1->time,any->theta,any->NLOC);
	diffllmut = ll[0]-whichnode->ll_left;

	ll[1]=ll_mut(whichnode->descendent2->genotype,newhap,whichnode->time
		-whichnode->descendent2->time,any->theta,any->NLOC);
	diffllmut += ll[1]-whichnode->ll_right;
    }

    x= exp(diffllmut);

    if (ranDum()<x) {
	any->llmut += diffllmut;
	whichnode->ll_left=ll[0];
	whichnode->ll_right=ll[1];
	for (i=1;i<=any->NLOC;i++) whichnode->genotype[i]=newhap[i];
	if (whichnode->ancestor!=NULL) whichnode->ancestor->ll_left=ll[2];
	free_ivector(newhap,1,any->NLOC);
#ifdef CHECK
	checktree(any,"after metro_haplotypes");
#endif
	return 1;
    }
    free_ivector(newhap,1,any->NLOC);
    return 0;
}
/***********************************************************************/
