#ifndef PARAMETERS_H_
#define PARAMETERS_H_
#include "prior.h"
#include "tree.h"
typedef struct parametertypes parameters;
struct parametertypes {
    int reps,warmup,Nbetsamp,treebetN,seed;
    prior Nprior,muprior;
    double tuneN,tunemu,badness;
    int **genetic_data, nloci, samplesize,picgap;
    char datafilename[40];
};
parameters setup_parameters(const char *file);
void printpardetails(parameters *any,FILE *out);
tree treestartup(parameters *p);
void output_line(FILE *OUTFILE ,tree *any);
void append_output_line(char *filename, tree *any);
#endif
