#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "random.h"
#include "metro.h"
#include "cutjoin.h"
#include "utils.h"
#include "pars.h"
#ifdef CHECK
#include "check.h"
#endif
#include "Newick.h"
/**************************************************************************/
int main(int argc ,char *argv[])
{
    tree t;
    parameters p;
    double prop[5];
    int i,j,k,pic_count=1;
    char picname[40],picstr[30];
    FILE *OUTFILE, *PARS;

    if (argc!=3) {
        printf("use:\nmicsat infile outfile\n");  
        exit(0);
    }
    p = setup_parameters(argv[1]);
    starTup(p.seed);
    strcpy(picname,argv[2]);
    strcpy(picstr,picname);
    PARS = fopen(strcat(picname,".par"),"w");
    if (!PARS) myerror("error opening parfile\n");
    printpardetails(&p,stdout);
    printpardetails(&p,PARS);

    t = treestartup(&p);

    OUTFILE = fopen(argv[2],"w");
    if (!OUTFILE) myerror("error opening outfile\n");
   
    prop[0]=prop[1]=prop[2]=prop[3]=prop[4]=0.0;
  
    strcpy(picname,picstr);
    write_Newick(t.root,strcat(picname,".iit"),t.info);
#ifdef CHECK
    checktree(&t,"before anything has started"); 
#endif 
    printf("Warmup");  		/* warmup				*/
    for (i=1;i<=p.warmup;i++) {
	for (j=1;j<=p.Nbetsamp;j++) {
	    for (k=1;k<= p.treebetN;k++) {
		metro_cutjoin(&t);
		metro_times(&t); 
		metro_haplotype(&t);
		
	    }
	    metro_mu(&t,p.tunemu);
	    metro_N(&t,p.tuneN);
	}
	if (i%20==1) {  	/*  it is nice to see something moving	*/
	    if (i%1000==1) printf("\n."); 
	    else  printf("."); 
	    fflush(stdout);
	} 
    }
    printf("\nGetting Samples");/* Now start collecting samples		*/
    for (i=1;i<=p.reps;i++) {
	for (j=1;j<=p.Nbetsamp;j++) {
	    for (k=1;k<=p.treebetN;k++){
		prop[0]+=(double)metro_cutjoin(&t); 	
		prop[1]+=(double)metro_times(&t);
		prop[4]+=(double)metro_haplotype(&t);
	    }
	   prop[2]+=(double)metro_mu(&t,p.tunemu);
	    prop[3]+=(double)metro_N(&t,p.tuneN);
	}
	fprintf(OUTFILE,"%g %g ",t.lltimes,t.llmut);
	output_line(OUTFILE,&t);
	if (i%20==1) {
	    if (i%1000==1) printf("\n."); 
	    else printf("."); 
	    fflush(stdout);
	}
	if (i%p.picgap==0) {	/* Get a picture (Newick) of the tree 	*/
	    get_counter_filename(picname,picstr,pic_count);
	    write_Newick(t.root,picname,t.info);
	    append_output_line(picname,&t);
	    pic_count+=1;
	}
    } 
    fclose(OUTFILE);
    printf("\n");
    strcpy(picname,picstr);
    write_Newick(t.root,strcat(picname,".end"),t.info);
    prop[0]/=(double)(p.reps)*(double)(p.Nbetsamp)*(double)(p.treebetN);
    prop[1]/=(double)(p.reps)*(double)(p.Nbetsamp)*(double)(p.treebetN);
    prop[4]/=(double)(p.reps)*(double)(p.Nbetsamp)*(double)(p.treebetN);
    
    prop[2]/=(double)(p.reps)*(double)(p.Nbetsamp);
    prop[3]/=(double)(p.reps)*(double)(p.Nbetsamp);

    printf("\nproportion accepted:\ntree %g\ntimes %g\nhaplotype %g\n",
	    prop[0],prop[1],prop[4]);
    fprintf(PARS,"\nproportion accepted:\ntree %g\ntimes %g\nhaplotype %g\n"
	    ,prop[0],prop[1],prop[4]);
    printf("mu %g\nN %g\n",prop[2],prop[3]);
    fprintf(PARS,"mu %g\nN %g\n\n",prop[2],prop[3]);
    fclose(PARS);
    destroy_tree(&t);
    return 1;
}

