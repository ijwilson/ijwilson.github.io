#ifndef CUTJOIN_H
#define CUTJOIN_H
#include "node.h"
#include "tree.h"

typedef struct cjtype cj;

struct cjtype {
    node *cut,*father,*brother, /*the node to move its father and its brother*/
         *addabove,*addbelow, /* the node to add and its ancestor            */
         *here,*grandfather;       /* the node with time less than newtime   */
	 
    double ll[4],lprobfor,lprobback,diffllmut,
    		difflltime,newtime;
    int nochange,*nwhap;
};

int metro_cutjoin(tree *t);
#endif

