/*
 * This is the tree changing function.
 * Choose a node to remove from the tree, node cut, 
 * also keep note of that node's brother, father, and grandfather
 * Then choose a place to add the node from
 * the entire tree which is "early" enough
 * except for nodes cut and father
 * to ensure that the forward and back probabilities are
 * easy to calculate. 
 *
 * The backwards probabilities are then simply the 
 * probability of adding the node above its brother.
 *
 * I now want to simplify the routines in this section.  */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "cutjoin.h"
#include "random.h"
#include "lhood.h"
#include "time.h"
#include "utils.h"
#ifdef CHECK
#include "check.h"
#endif
#define DO_LOCUS_LOOP for (locus=1;locus<=any->NLOC;locus++)
#define DO_LOCUS_LOOPb for (locus=1;locus<=nloci;locus++)

/********************************************************************/
/*  The Metropolis function for stepping between trees              */
/********************************************************************/
int metro_cutjoin(tree *any)
{
    cj attempt;
    double x;

    cj getcutadd(tree *any);
    double getllcj(tree *any, cj *att);
    void attachnew(tree *any,cj *att);
    void destroy_cj(cj *any);

    attempt = getcutadd(any);  /* find the attempted change             */
    x = getllcj(any,&attempt); /* what is the probability of acceptance */
    if ((x>1.0)||(ranDum()<x)) {
	attachnew(any,&attempt);
#ifdef CHECK
	checktree(any,"after cutjoin");
#endif
	destroy_cj(&attempt);
	return 1;
    } 
    destroy_cj(&attempt);
    return 0;
}
/********************************************************************/
/*  A function for attaching the new tree if it is accepted         */
/********************************************************************/
void attachnew(tree *any, cj *att)
{
    int locus;

    DO_LOCUS_LOOP 
	att->father->genotype[locus] = att->nwhap[locus];
    
    any->lltimes += att->difflltime; 
    any->llmut += att->diffllmut;

    if (att->nochange==0) {     	/* we need to alter the shape */
	att->father->descendent2=att->addabove; 
	att->addabove->ancestor=att->father;
	att->father->ll_left=att->ll[1];
	att->father->ll_right=att->ll[2];
	if (att->addbelow==NULL) {	/* Adding at the top of the tree ? */  
	    any->root=att->father; 	/* change the root                 */
	    att->father->ancestor=NULL;
	    any->totallength+=
		2.*att->newtime-att->father->time-att->addabove->time;
	    att->brother->ancestor = att->grandfather;  
	    att->grandfather->descendent1=att->brother;
	    att->grandfather->ll_left = att->ll[0];
	}
	else if (!att->grandfather) {	/* removing the top of the tree  */
	    any->root = att->brother;
	    att->brother->ancestor=NULL;
	    any->totallength+=
		att->newtime-2.*att->father->time+att->brother->time;	
	    att->addbelow->descendent2=att->father;
	    att->father->ancestor=att->addbelow;
	    att->addbelow->ll_right=att->ll[3];
	}
	else { 			/* all in the middle of the tree  */
	    any->totallength += (att->newtime - att->father->time); 
	    att->brother->ancestor = att->grandfather; 
	    att->grandfather->descendent1=att->brother;
	    att->grandfather->ll_left = att->ll[0];
	    att->addbelow->descendent2=att->father;
	    att->father->ancestor=att->addbelow;
	    att->addbelow->ll_right=att->ll[3];
	}
    }
    else {  /* no change in the tree shape    */
	att->father->ll_left=att->ll[1];
	att->father->ll_right=att->ll[2];
	if (att->grandfather){
	    any->totallength +=att->newtime-att->father->time;
	    att->grandfather->ll_left=att->ll[0];
	}
	else 
	    any->totallength +=2.*(att->newtime-att->father->time);
    }
    any->first = remaketimes(any->first,att->here,att->father,att->newtime);
}
/********************************************************************/
/*    find the attempted new tree                                   */
/********************************************************************/
cj getcutadd(tree *any)
{
    cj back;
    int which;

    int *getnewhap(cj *back, int nloci);
    void wheretoadd(cj *from,node *sample,node *first,int *info);
    double getnewtime(cj *att);

    for (;;) {    /* choose the node to remove (not the root) */
        which = (int)(ranDum()*(2.*(double)(any->SS)-1.)) + 1;
        if (any->sample[which].ancestor != NULL) break;
    }

    back.cut = any->sample + which; 		/* the node to cut out 	*/
    back.father = back.cut->ancestor;   	/*    and its ancestor 	*/
    back.grandfather = back.father->ancestor;  	/*    and its ancestor	*/
    back.brother=back.father->descendent2;     	/* the sibling of cut	*/
    
    if (back.father->descendent1 != back.cut) 	/* ensure orientation 	*/
	nodeswap(back.father);           	/* of father		*/
    if (back.grandfather!=NULL)			/* and (if there is one)*/
	if (back.grandfather->descendent1 != back.father) 
	    nodeswap(back.grandfather);		/* of grandfather	*/
    
    back.brother=back.father->descendent2;     	/* the sibling of cut 	*/
    wheretoadd(&back,any->sample,any->first,any->info);/* find where to add*/ 
    back.addbelow = back.addabove->ancestor; 	/* where to add below	*/

    if (back.addbelow==back.father) {		/* no change in shape	*/
	back.addbelow=back.grandfather; 
	back.nochange=1; 
    }
    else if (back.addbelow != NULL) {
	if (back.addbelow->descendent2!=back.addabove) nodeswap(back.addbelow);
	back.nochange=0;
    }
    else back.nochange=0;

    back.nwhap=getnewhap(&back,any->NLOC);
    back.newtime=getnewtime(&back);

    return back;
}
/********************************************************************/
/*    Where to add the cut node                                     */
/********************************************************************/
void wheretoadd(cj *from,node *sample,node *first, int *info)
{
    double *prob;
    int *use,wherecount=0,which;
    node *current;

    double simpledistance(haptype gen1,haptype gen2, int nloc);

    prob = dvector(1,2*SS);
    use = ivector(1,2*SS);
    current= first;

    for (;;) {
	if (from->cut->time<current->time) {
	    if (from->father==current) {
		use[++wherecount]=from->brother-sample;
		prob[wherecount]=
		    simpledistance(from->brother->genotype,
			    from->cut->genotype,NLOC);
		from->lprobback=log(prob[wherecount]);
	    }
	    else {
		if (from->father!=current->descendent1){
		    use[++wherecount]=current->descendent1-sample;
		    prob[wherecount]=
			simpledistance(current->descendent1->genotype,
				from->cut->genotype,NLOC);
		}
		use[++wherecount]=current->descendent2-sample;
		prob[wherecount]=
		    simpledistance(current->descendent2->genotype,
			    from->cut->genotype,NLOC);
	    }
	}
	if (current->next==NULL) break;
	else current=current->next;
    }
    /* now above the root */
    if (from->father!=current) {
	use[++wherecount]=current-sample; /* should be the root*/
	prob[wherecount]=
	    simpledistance(current->genotype,from->cut->genotype,NLOC);
    }

    from->addabove = sample+use[which=gen_from_probs(prob,wherecount)];
    from->lprobfor = log(prob[which]);

    free_ivector(use,1,2*SS);
    free_dvector(prob,1,2*SS);
}

/***********************************************************************/
/*   What is the log-likelihood of the attempted new tree ?            */
/***********************************************************************/
double getllcj(tree *any, cj *att)
{
    att->diffllmut=0.0;
  
    if (att->nochange) {
	if (att->grandfather){
	    att->ll[0]=ll_mut(att->grandfather->genotype,att->nwhap,
		    att->grandfather->time-att->newtime,any->theta,any->NLOC);
	    att->diffllmut += att->ll[0]-att->grandfather->ll_left;
	}
	att->ll[1] = ll_mut(att->cut->genotype,att->nwhap,
		att->newtime-att->cut->time,any->theta,any->NLOC);
	att->diffllmut += att->ll[1]-att->father->ll_left;
	att->ll[2] = ll_mut(att->addabove->genotype,att->nwhap,
		att->newtime-att->addabove->time,any->theta,any->NLOC);
	att->diffllmut += att->ll[2]-att->father->ll_right;
    }
    else {
	if (att->grandfather) { 
	    att->ll[0]=ll_mut(att->grandfather->genotype,att->brother->genotype,
		    att->grandfather->time-att->brother->time,any->theta
		    ,any->NLOC);
	    att->diffllmut = att->ll[0]-att->grandfather->ll_left;
	} 
	att->ll[1] = ll_mut(att->cut->genotype,att->nwhap,
		att->newtime-att->cut->time,any->theta,any->NLOC);
	att->diffllmut += att->ll[1]-att->father->ll_left;
	att->ll[2] = ll_mut(att->addabove->genotype,att->nwhap,
		att->newtime-att->addabove->time,any->theta,any->NLOC);
	att->diffllmut += att->ll[2]-att->father->ll_right;
	if (att->addbelow!=NULL) {
	    att->ll[3] = ll_mut(att->addbelow->genotype,att->nwhap,
		    att->addbelow->time-att->newtime,any->theta,any->NLOC);
	    att->diffllmut += att->ll[3]-att->addbelow->ll_right;
	}
    }
    att->here = difflltcj(&(att->difflltime),any->first,att->father
	    ,att->newtime,any->info);

    return exp(att->difflltime+att->diffllmut-att->lprobfor+att->lprobback);
}
/********************************************************************/
/*  Function for the distance between a pair of haplotypes          */
/********************************************************************/
double simpledistance(haptype gen1,haptype gen2, int nloci)
{  
    int locus,tmp=0;

    DO_LOCUS_LOOPb
	tmp += abs(gen1[locus] - gen2[locus]);

    return 1./((double)tmp + 1.); /* note the change here  */
}
/**********************************************************************/
/*   Get the new time and the probabilities backwards and forwards    */
/**********************************************************************/
double getnewtime(cj *att) 
{
    double mintime,nwtime;

    if (att->cut->time > att->brother->time) 
	mintime =att->cut->time ;
    else mintime = att->brother->time;
    if (att->grandfather != NULL) 
	att->lprobback -= log(att->grandfather->time-mintime);
    else 
	att->lprobback -= (att->father->time - mintime);

    if (att->cut->time>att->addabove->time)
	mintime = att->cut->time;
    else mintime = att->addabove->time;
    if (att->addbelow != NULL) {
	nwtime = mintime + ranDum()*(att->addbelow->time-mintime);
	att->lprobfor -= log(att->addbelow->time-mintime);
    } else {
	nwtime = mintime-log(ranDum());
	att->lprobfor -= nwtime-mintime;
    } 
    return nwtime;
}
/**********************************************************************/
int *getnewhap(cj *back,int nloci)
{
    int locus,mini,maxi,*newhap;
    double mean,sd,cn;

    newhap = ivector(1,nloci);

    DO_LOCUS_LOOPb {
	if (back->cut->genotype[locus]<back->addabove->genotype[locus]){
	    mini = (double) back->cut->genotype[locus];
	    maxi = (double) back->addabove->genotype[locus];
	} else {
	    mini = (double)  back->addabove->genotype[locus];
	    maxi = (double)  back->cut->genotype[locus];
	}
	mean = (double)(mini + maxi) / 2.0;
	sd = (double)(maxi - mini + 1.)/4.0;
	newhap[locus] = (int) rint(mean + sd * normal());
	back->lprobfor += 
	    log(cumnorm((double) newhap[locus] + 0.5, mean, sd) -
		    cumnorm((double) newhap[locus]-0.5,mean, sd));
	if (back->nochange) {
	    cn = cumnorm((double) back->father->genotype[locus]+0.5,mean,sd) -
		cumnorm((double) back->father->genotype[locus]-0.5, mean,sd);
	}
	else {
	    if (back->cut->genotype[locus] < back->brother->genotype[locus]) {
		mini = (double) back->cut->genotype[locus];
		maxi = (double) back->brother->genotype[locus];
	    } else {
		mini = (double) back->brother->genotype[locus];
		maxi = (double) back->cut->genotype[locus];
	    }
	    mean =(double) (mini + maxi) / 2.0;
	    sd =(double) (maxi - mini + 1.)/4.0;

	    cn = cumnorm((double) back->father->genotype[locus]+0.5,mean,sd) -
		cumnorm((double) back->father->genotype[locus]-0.5, mean,sd);
	}
	if (cn > 0.0) back->lprobback += log(cn);
	else back->lprobback += -1E100;
    }
    return newhap;
}
/********************************************************************/
/*  A function for destroying the attempted new tree                */
/********************************************************************/
void destroy_cj(cj *any)
{
    free_ivector(any->nwhap,1,2);
    return;
}
/********************************************************************/
