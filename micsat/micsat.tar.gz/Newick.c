/*
 * Functions for Output and Input of Trees in Newick File Format.
 * 
 * Defines:
 * 
 * USE_LABELS - for outputing labelled trees (debugging) 
 * 
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "Newick.h"
#include "utils.h"
#include "tree.h"
#include "node.h"
/***********************************************************************/
void writenode(FILE *out,node *any, int *info)
{
    int i;

    fprintf(out,"'");
    for (i = 1; i < NLOC; i++)
	fprintf(out, "%d-", any->genotype[i]);
    fprintf(out, "%d'", any->genotype[NLOC]);
}
/***********************************************************************/
void writeutil(node *anynode, FILE *out, int *info)
{
    fprintf(out, "(");
    if (anynode->descendent1->descendent1 != NULL) 
	writeutil(anynode->descendent1, out,info );
    writenode(out,anynode->descendent1,info);
    fprintf(out, ":%10.6g",anynode->time - anynode->descendent1->time);
    fprintf(out,",");
    if (anynode->descendent2->descendent1 != NULL)	
	writeutil(anynode->descendent2, out, info);
    writenode(out,anynode->descendent2,info);
    fprintf(out, ":%10.6g",anynode->time - anynode->descendent2->time);
    fprintf(out, ")");
}
/***********************************************************************/
void write_Newick(node *root, char *filename, int *info)
{
    FILE *output;

    output = fopen(filename, "w");
    if (!output) myerror("error opening output file");

    writeutil(root, output, info);
    writenode(output,root,info);
    fprintf(output,";");
    fclose(output);
}

