#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "prior.h"
#include "utils.h"
/***************************************************************************/
void printpriortype(prior a,FILE *out)
{
    int i;
    switch (a.prtype) {
	case 0: 
	    fprintf(out,"uniform\n");
	    break;
	case 1: 
	    fprintf(out,"gamma(%g,%g)\n",a.par[0],a.par[1]);
	    break;
	case 2: 
	    fprintf(out,"lognormal(%g,%g)\n",a.par[0],a.par[1]);
	    break;
	case 3: 
	    fprintf(out,"normal(%g,%g)\n",a.par[0],a.par[1]);
	    break;
	case 4: 
	    fprintf(out,"dirichlet (");
	    for (i=1;i<(int)a.par[0];i++)
		fprintf(out,"%g,",a.par[1]);
	    fprintf(out,"%g)\n",a.par[1]);
	    break;
	default: 
            fprintf(out,"prior %d not defined yet",a.prtype);
	    exit(0);
    }
    return;
}
/************************************************************************/
#define MY_SQRT_2PI 0.398942280401432677939946059934
#define LMY_SQRT_2PI -0.918938533204672669540968854562
double log_prior(double *x, prior a)
{
    double lx,*alpha;
    int i,n;

    switch (a.prtype) {
	case 0:   				/* uniform prior */
	    return 0.0;

	case 1:    				/* gamma prior */
	    return a.par[0]*log(a.par[1])+(a.par[0]-1.)*
		log(*x)-a.par[1]*(*x)-lgamma(a.par[0]);

	case 2:       				/* lognormal prior  */
	    lx = (log(*x) - a.par[0]) / a.par[1];
	    return LMY_SQRT_2PI - 0.5 * lx * lx - log(a.par[1]) - log(*x);

	case 3:    				/* Normal prior    */
	    lx = (*x-a.par[0])/a.par[1];
	    return LMY_SQRT_2PI - log(a.par[1]) - 0.5*lx*lx;

	case 4:					/* Dirichlet prior	*/
	    n = (int)a.par[0];			/* so far only with equal */
	    alpha=dvector(1,n);			/* expected frequencies   */
	    lx=0.0;
	    for (i=1;i<=n;i++) {
		alpha[i]=a.par[1];
		lx += a.par[1]*log(x[i]);
	    }
	    lx -= log_D(alpha,n);
	    free_dvector(alpha,1,n);
	    return lx;

	default:
	    printf("this prior not written yet");
	    return 0.0;
    }
}
/*************************************************************************/
void copyprior(prior *to, prior from)
{
    to->par[0]=from.par[0];
    to->par[1]=from.par[1];
    to->prtype=from.prtype;
}
