#ifndef _UTILS_H_
#define _UTILS_H_
void get_counter_filename(char *name, char *base, int count);
void myerror(char *text);
int *ivector(int nl, int nh);
double *dvector(int nl, int nh);
int **imatrix(int nrl, int nrh, int ncl, int nch);
void free_ivector(int *v, int nl, int nh);
void free_dvector(double *v, int nl, int nh);

double log_D(double b[], int n);

double cumnorm(double x, double mean, double var);

double edbesi0(double x);
double edbesi1(double x);  
double edbesi(int n, double x);


#endif
