#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "lhood.h"
#include "time.h"
#include "utils.h"
#include "node.h"
#include "tree.h"
#define DO_LOCUS_LOOP for (locus=1;locus<=nloc;locus++)

/************************************************************************/
/* The probability of mutating from *from to *to in time                */
/************************************************************************/
double ll_mut(int *a,int *b, double time,double theta, int nloc)
{
    int locus,d;
    double tmp=0.0,s0=0.0,s1=0.0,tt;
    tt=theta*time*0.5;
    DO_LOCUS_LOOP {
	d = abs(a[locus]-b[locus]);
	if (d==0) {
	    if (s0>=0.0)
		s0 = log(edbesi0(tt));
	    tmp += s0;
	}
	else if (d==1) {
	    if (s1>=0.0)
		s1 = log(edbesi1(tt));
	    tmp += s1;
	}
	else tmp += log(edbesi(d,tt));
    }	
    return tmp;
}
/************************************************************************/
double nonrecursivelikelihood(node *first,double theta, int *info) 
{
    double temp=0.0;
    node *cur;

    cur = first;
    for (;;) {
	cur->ll_left = ll_mut(cur->genotype,cur->descendent1->genotype, 
		cur->time-cur->descendent1->time,theta,NLOC);
	cur->ll_right = ll_mut(cur->genotype,cur->descendent2->genotype, 
		cur->time-cur->descendent2->time,theta,NLOC);
	temp += cur->ll_left+cur->ll_right;
	if (cur->next==NULL) break;
	cur=cur->next;
    }
    return temp;
}
/************************************************************************/
lltype loglikelihoodtheta(tree *thistree, double theta)
{
	return nonrecursivelikelihood(thistree->first,theta,thistree->info);
}
/************************************************************************/
double  loglikelihoodtimes(tree * any)
{
	return lprobtimes(any->first,any->info);
}
/************************************************************************/
