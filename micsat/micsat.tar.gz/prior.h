#ifndef PRIOR_H_
#define PRIOR_H_

typedef struct priortype prior;

struct priortype{
    int prtype;
    double par[2];
};

double log_prior(double *x, prior a);
void printpriortype(prior a, FILE *out);
void copyprior(prior *to, prior from);

#endif
