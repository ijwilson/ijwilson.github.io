#ifndef TREE_H
#define TREE_H

#include "node.h"
#include "prior.h"

typedef node *sampletype;	/* A single genealogy       	*/
typedef double lltype;   	/* likelihoods a scalar		*/

#define SS 		info[0]	
#define NLOC 		info[1]

#define MUPRIOR 	priors[0]
#define NPRIOR		priors[1]

typedef struct treetype tree;

struct treetype {   
    int info[2];		/* shortcut information
	                		info[0] - n
					info[1] - nloc		*/
    prior priors[2];		/*	priors[1] - mu
					priors[2] -  N		*/
    sampletype root;          	/* the root             	*/ 
    sampletype ancestors;     	/* the ancestors            	*/ 
    sampletype sample;        	/* and the sample            	*/ 
    sampletype first;         	/* the first event           	*/
    lltype llmut;             	/* log likelihood mutations  	*/
    lltype lltimes;           	/* log likelihood times      	*/ 
    lltype totallength;       	/* total length of tree      	*/ 
    double theta;            	/* theta                    	*/
    double mu;               	/* The mutation rate per meiosis*/
    double N;			/* Self Explanatory ?		*/
};

void destroy_tree(tree *anytree);
tree starting_tree(int **genotype, int samplesize, int nloc
	, double badness);
#endif
