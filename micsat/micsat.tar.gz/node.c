#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include "utils.h" 
#include "node.h"


/*******************************************************************/
/*   Count the descendents of a node                               */
/*******************************************************************/
int count_end_nodes(node *anynode)
{
   if (anynode->descendent1==NULL) return 1;
   else return count_end_nodes(anynode->descendent1)+
         count_end_nodes(anynode->descendent2);
}
/*******************************************************************/
/*     Calculate the length of the tree below a node               */
/*******************************************************************/
double calc_length(node *anynode) 
{
    double temp=0.0;

    if (anynode->descendent1==NULL) temp = anynode->time;
    else temp = calc_length(anynode->descendent1) + 
                  anynode->time-anynode->descendent1->time;

    if (anynode->descendent2==NULL) temp += anynode->time;
     else temp += calc_length(anynode->descendent2) + 
                  anynode->time-anynode->descendent2->time;

    return temp;
}
/*******************************************************************/
/*  Swap the descendents and their respective log_likelihoods      */
/*******************************************************************/
void nodeswap(node *anynode) 
{
    node *tmp;
    double dtmp;

    tmp =anynode->descendent2;
    anynode->descendent2=anynode->descendent1;
    anynode->descendent1=tmp;

    dtmp=anynode->ll_right;
    anynode->ll_right=anynode->ll_left;
    anynode->ll_left=dtmp;
} 


/******************************************************************/
/*  Take the times and remove the time at *old replacing it       *
 *  with newtime and reorder the nodes (placing *old after *here) */
/******************************************************************/
node *remaketimes(node *first, node *here, node *old, double newtime)
{
    node *tmp,*tmp2;

    if (newtime<old->time) {
	tmp=here->next;
	if (tmp==old) {
	    old->time = newtime;
	    return first;
	}
	if (old==first) {
	    old->prev->next=old->next;
	    old->next->prev = old->prev;
	    here->next=old;
	    old->next=tmp;
	    old->prev=here;
	    tmp->prev=old;
	    old->time=newtime;
	    return old->next;
	}
	if (tmp==first) {
	    old->prev->next=old->next;
	    if (old->next !=NULL) old->next->prev = old->prev;
	    here->next=old;
	    old->next=tmp;
	    old->prev=here;
	    tmp->prev=old;
	    old->time=newtime;
	    return old;
	}
	old->prev->next=old->next;
	if (old->next!=NULL) old->next->prev = old->prev;
	here->next=old;
	old->next=tmp;
	old->prev=here;
	tmp->prev=old;
	old->time=newtime;
	return first;
    }
    else {
	if (here==old) {
	    old->time=newtime;
	    return first;
	}
	else {  
	    tmp=here->next;
	    old->prev->next=old->next;
	    if (old->next!=NULL) old->next->prev = old->prev;
	    if (old==first) tmp2=first->next;
	    else tmp2=first;
	    here->next=old;
	    old->next=tmp;
	    old->prev=here;
	    if (tmp!=NULL) tmp->prev=old;
	    old->time=newtime;	
	    return tmp2;
	}
    }
}

