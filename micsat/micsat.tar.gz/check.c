#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include <values.h>
#include "utils.h" 
#include "time.h"
#include "tree.h"
#include "random.h"
#include "node.h"
#include "lhood.h" 
#include "check.h"

/*****************************************************************************/
/*  Checking Algorithms                                                      */
/*****************************************************************************/
void checknode(node *anynode)
{
    if (anynode->descendent1) {
	if (anynode->descendent1->ancestor!=anynode) {
	    printf("error in descendent1\n");
	}
	checknode(anynode->descendent1);
    }
    if (anynode->descendent2) {
	if (anynode->descendent2->ancestor!=anynode) {
	    printf("error in descendent2 \n");
	}
	checknode(anynode->descendent2);
    }
}
/*****************************************************************************/ 
void checktree(tree *anytree, char message[])
{
    lltype l;
    int i;
    node *here;

    int checklinkedtimes(char *message, node *first);

    if (checklinkedtimes(message,anytree->first)!=anytree->SS-1) {
	printf("%s: linked list too short",message);
	exit(0);
    }
 
    if (fabs(anytree->theta-2.0*anytree->mu*anytree->N)>0.000001){
	printf("%s theta %g sep %g %g %g\n" ,message,
		anytree->theta,2.0*anytree->mu*anytree->N,
		anytree->mu,anytree->N);
	myerror("error with theta");
    }
    checknode(anytree->root);    

    l=loglikelihoodtimes(anytree);

    if (fabs(anytree->totallength-calc_length(anytree->root))>0.0001){
	printf("%s: problem with length %g %g\n",message,
		calc_length(anytree->root),anytree->totallength);
	anytree->totallength=calc_length(anytree->root);
    }

    if (fabs(l-anytree->lltimes)>0.0001) {
	printf("%s: problem with times %g %g %g\n",message,
		l,anytree->lltimes,l-anytree->lltimes);
	myerror("stop!!!");
	anytree->lltimes=l;
    }
    anytree->lltimes=l;
    
    here=anytree->first;
    for (i=1;i<anytree->SS;i++) {

	if (fabs(ll_mut(here->genotype,here->descendent1->genotype,
		here->time-here->descendent1->time,anytree->theta,
		anytree->NLOC)
		-here->ll_left)>0.000001){

	    printf("%s: internal problem descendent1: old %g calc %g \n ",
		    message,here->ll_left,
		    ll_mut(here->genotype,here->descendent1->genotype,
			here->time-here->descendent1->time,anytree->theta,
			anytree->NLOC));
	    here->ll_left = ll_mut(here->genotype,
		    here->descendent1->genotype,
		    here->time-here->descendent1->time,anytree->theta,
		    anytree->NLOC);
	}

	if (fabs(ll_mut(here->genotype,here->descendent2->genotype,
			here->time-here->descendent2->time,anytree->theta,
			anytree->NLOC)-here->ll_right)>0.000001){

	    printf("%s: internal problem descendent 2: old %g calc %g \n ",
		    message,here->ll_right, 
		    ll_mut(here->genotype,here->descendent2->genotype,
			here->time-here->descendent2->time,anytree->theta,
			anytree->NLOC));
	    here->ll_right =ll_mut(here->genotype,
		    here->descendent2->genotype,
		    here->time-here->descendent2->time,anytree->theta,
		    anytree->NLOC); 
	}
	here=here->next;
    }
    l=loglikelihoodtheta(anytree,anytree->theta);

    if (fabs(l-anytree->llmut)>0.0001) {
	printf("%s:problem with muts %g %g\n",message,l,anytree->llmut);
	anytree->llmut=l;
	l=loglikelihoodtheta(anytree,anytree->theta);
    }
}
/********************************************************************/
int checklinkedtimes(char *message, node *first)
{
    int count=1;
    node *current;

    current=first;
    for (;;) {
	if (current->prev->next!=current) {
	    printf("%s %d error 3\n",message,count);
	    exit(0);
	}
	if (current->next==NULL) break;
	if (current->next->time<=current->time) {
	    printf("%s %d error 1\n %g %g",
		    message,count,current->next->time,current->time);
	    exit(0);
	}
	if (current->next->prev!=current) {
	    printf("%s %d error 2\n",message,count);
	    exit(0);
	}
	count +=1;
	current=current->next;
    }
    return count;
}
