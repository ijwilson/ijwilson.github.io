#ifndef RANDOM_H
#define RANDOM_H

/***********************************************************/
/*  Definition:   Which random number generators do we use */
/***********************************************************/
/*#define USE_CDROM_RAND*/ /* only if you have the CD  */
/*#define USE_MARS   */
/* #define USE_KISS  */  
/***********************************************************/

#define ranDum dkiss
#define starTup start_kiss
double dkiss(void);
void start_kiss(int seed);
/***********************************************************/


int  gen_from_p(double  *p, int n);
int  gen_from_probs(double  *p, int n);
double normal(void);

#endif



