/************************************************************************/
/* Functions for Dealing with time, both simple
 * for a constant size model, and also for changing
 * population sizes.  
 */
/************************************************************************/
/* Include Files                                                        */
/************************************************************************/

#include <math.h>           
#include <stdio.h>
#include <stdlib.h>         
#include "node.h"
#include "tree.h"
#include "time.h"         
#include "utils.h"

#ifdef CHECK
#include "check.h"
#endif


/************************************************************************/
/*  First functions for  
 *  likelihoods of a  variety of different 
 *  population structures                                               */
/************************************************************************/
double lprobtimes(node *first,int *info)
{
    double temp=0.0,nleft,starttime=0.0;
    node *current;
    int i;

    current=first;
    nleft = (double) SS;
    for (i=1;i<SS;i++){
	temp += -0.5*nleft*(nleft-1.)*(current->time-starttime);
	nleft-=1.0;
	starttime=current->time;
	current=current->next; 
    }
    return temp;
}
/************************************************************************/
double lptime(double left,double starttime,double endtime)
{
    return -0.5*left*(left-1.)*(endtime-starttime);
}
/************************************************************************/
node *difflltcj(double *ll,node *first,node *old, double newtime, 
	int *info)
{
    double temp=0.0,left;
    int i;
    node *current,*to_return;

    if (old->time<newtime) {
	if (old->next==NULL) {    /* at the end so no need to step through  */
	    *ll = lptime(2.0,old->prev->time,newtime) -
		    lptime(2.0,old->prev->time,old->time);
	    return old; 
	}
	current=first;
	for (i=1;i<SS;i++) {      /* Find the position of the old node      */
	    if (current==old) break;
	    current=current->next;
	}
	left = (double)(SS-i);    /* How many lines of descent are left here */
	
	temp -=lptime(left+1.0,current->prev->time,current->time);
	temp -=lptime(left,current->time,current->next->time);

	if (newtime<current->next->time) { /* newtime is added here also */
	    temp += lptime(left+1.,current->prev->time,newtime);
	    temp += lptime(left,newtime,current->next->time);
	    *ll=temp;
	    return current;
	}
	
	temp+=lptime(left+1.,current->prev->time,current->next->time);
	current=current->next;

	for (;;) {
	    if (current->next==NULL) {
		temp += lptime(2.0,current->time,newtime);
		*ll=temp;
		return current;
	    }
	    if (newtime < current->next->time) {
		temp -= lptime(left-1.,current->time,current->next->time);
		temp += lptime(left,current->time,newtime);
		temp+=lptime(left-1.,newtime,current->next->time);
		*ll=temp;
		return current;
	    }
	    temp-=lptime(left-1.,current->time,current->next->time);	
	    temp += lptime(left,current->time,current->next->time);
	    left-=1.0;
	    current=current->next;
	}
    }
    else { /* The new time is less than the old time */
	current=first;
	for (i=1;i<SS;i++) {
	    if (newtime<current->time) break;
	    current=current->next;
	}
	to_return = current->prev;

	if (current->next==NULL) {
	    *ll= lptime(2.0,current->prev->time,newtime)
		    -lptime(2.0,current->prev->time,current->time);
	    return to_return;
	}
	left = (double)(SS-i);
	if (old==current) {
	    temp += lptime(left+1.,current->prev->time,newtime);
	    temp += lptime(left,newtime,current->next->time);
	    temp -= lptime(left+1.0,current->prev->time,current->time);
	    temp -= lptime(left,current->time,current->next->time);
	    *ll=temp;
	    return to_return;
	}
	
	temp += lptime(left+1.0,current->prev->time,newtime);
	temp += lptime(left,newtime,current->time);
	temp -= lptime(left+1.0,current->prev->time,current->time);

	left-=1.0;
	current=current->next;

	for (;;) {
	    if (current->next==NULL) {
		temp -= lptime(2.,current->prev->time,current->time);
		*ll=temp;
		return to_return;
	    }
	    if (current==old) {
		temp -= lptime(left,current->time,current->next->time);
		temp -=lptime(left+1.0,current->prev->time,current->time);
		temp+=lptime(left,current->prev->time,current->next->time);
		*ll=temp;
		return to_return;
	    }
	    temp +=lptime(left,current->prev->time,current->time);
	    temp-=lptime(left+1.,current->prev->time,current->time);
	    current=current->next;
	    left-=1.0;
	}
    }
}
/***************************************************************************/
