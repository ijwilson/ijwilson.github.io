/*  This hold the essential building blocks for all */
/*  Tree programs                                   */
/*           node structure                         */
/*   use #defines to get the features that we want  */
/*   these defines should be in node.h              */
   
#ifndef NODE_H
#define NODE_H


typedef int *haptype;

typedef struct nodetype node;
struct nodetype {
    int *genotype;
    double time;
    double ll_left;
    double ll_right;
    node *descendent1;
    node *descendent2;
    node *ancestor;    
    node *next;
    node *prev;
};
int count_end_nodes(node *anynode);
double calc_length(node *anynode);
void nodeswap(node *anynode);	
node *remaketimes(node *first, node *here, node *old, double newtime);
#endif
