#ifndef MYTIME_H
#define MYTIME_H
#include "node.h"
#include "tree.h"
double lprobtimes(node *first,int *info);
node *difflltcj(double *ll,node *first,node *old, double newtime, 
	int *info);
double lptime(double left,double starttime,double endtime);
#endif
