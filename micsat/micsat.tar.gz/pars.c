/* an improvemtn on the old readwrite.c which has the advantage that the 
 * par files written out can be used as input for another session  */

#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "pars.h"
#include "tree.h"
#include "lhood.h"
#include "random.h"

#define FIRSTSIZE 1001
/*******************************************************************/
tree treestartup(parameters *p)
{
    tree t;
    
    t=starting_tree(p->genetic_data,p->samplesize,p->nloci,p->badness);
    
    copyprior(&(t.NPRIOR),p->Nprior);
    copyprior(&(t.MUPRIOR),p->muprior);
    
    t.N=10000.*ranDum();
    t.mu=ranDum()*0.005;
    t.theta=t.mu*t.N*2.0;

    t.lltimes = loglikelihoodtimes(&t);
    t.llmut=loglikelihoodtheta(&t,t.theta);

    return t;
}
/************************************************************************/
int skipspace(FILE * anyfile)
{
        static int      ch;

        while (isspace(ch = getc(anyfile)));
        return (ch);
}
/************************************************************************/
int skipblank(FILE * anyfile)
{
        static int      ch;

        for (;;) {
            ch = getc(anyfile);
            if (ch=='\n') return (ch);
            if (!isspace(ch)) return (ch);
        }
}
/************************************************************************/
int **readintegermatrix(char *filename,int *rows, int *columns)
{
    FILE *in;
    int i,j,*data,**toret,count=0,vecsize;
    static char ch;

    vecsize=FIRSTSIZE-1; /*there is a blank so I can start at 1*/

    in = fopen(filename,"r");
    if (!in) myerror("error opening input file");

    data = (int*)malloc(FIRSTSIZE*sizeof(int));
    if (!data) myerror("error allocating memory in readintegermatrix");

    /* first find out how many columns  */
    for (;;) {
	ch = skipblank(in);
	if (isdigit(ch)) {
	    ungetc(ch,in);
	    if (count==vecsize) {
		data = realloc(data,(vecsize+1000)*sizeof(int));
		if (!data) myerror("error reallocating data");
		vecsize +=1000;
	    }
	    fscanf(in,"%d",&(data[++count]));
	}

	else if ((ch =='\n')||(ch == EOF)) {
	    *columns = count;
	    break;
	}
	else
	    myerror("This file shopuld just contain integers");
    }
    /* now do the rest of the file  */
    for (;;) {
	ch = skipspace(in);
	if (isdigit(ch)) {
	    ungetc(ch,in);
	    if (count==vecsize) {
		data = realloc(data,(vecsize+1000)*sizeof(int));
		if (!data) myerror("error reallocating data");
		vecsize +=1000;
	    }
	    fscanf(in,"%d",&(data[++count]));
	}
	else break;
    }
    
    if (count%(*columns)!=0) {
        printf("WARNING the file does not *fill* out the matrix\n");
        *rows = count/(*columns) +1;
    }
    else *rows = count/(*columns);

    toret = imatrix(1,*rows,1,*columns);
    count =1;
    for (i=1;i<=*rows;i++) 
	for (j=1;j<=*columns;j++)
	    toret[i][j]=data[count++];
    free(data);
    fclose(in);
    return toret;
}
/*********************************************************************/
int findstart(FILE *in,char *pattern)
    /* searched through the file for the first 
     * time that pattern appears, 1 if a success 0 otherwise   */
{
    int c;
    unsigned long where = 0;
    char *p = pattern;
    rewind(in);
  
    while ((c = fgetc(in)) != EOF) {
        if (*p == c)
            p++;
        else
            p = pattern;
        if (!*p)
            return 1;
        where++;
    }
    return 0;
}
/*********************************************************************/
double nextdouble(FILE *in)
{
    int ch;
    float tmp;
    ch = skipspace(in);
    if (ch!=':')
	myerror("should be a colon before value ");
    fscanf(in,"%f",&tmp);
    return (double)tmp;
}
/*********************************************************************/
int nextname(FILE *in, char *filename)
    /*  filename must be at least 40 characters long */
{
    int ch,i;
    ch = skipspace(in); /* up to the colon */
    ch= skipspace(in);
    for (i=0;i<40;i++) {
	if ((isspace(ch))||ch=='(') {
	    ungetc(ch,in);
	    filename[i]='\0';
	    return 1;
	}
	filename[i]=ch;
	ch = getc(in);
    }
    return 0;
}
/*********************************************************************/
int get_doublesfrombrackets(FILE *in,double par[2]) 
{
    char ch;
    float f;
    
    ch=skipspace(in);
    if (ch!='(') return 0;
    fscanf(in,"%f",&f);
    par[0]=f;
    ch=skipspace(in);
    if (ch!=',') return 1;
    fscanf(in,"%f",&f);
    par[1]=f;
    ch=skipspace(in);
    if (ch==')') return 2;
    else {
	printf("only two parameters so far");
	return 0;
    }
}
/*********************************************************************/    
prior readprior(FILE *in)
{
    char name[40];
    prior tmp;

    if (!nextname(in,name))
	myerror("we need a prior type");
    if (strcmp("uniform",name)==0) tmp.prtype=0;
    else if (strcmp("gamma",name)==0) tmp.prtype=1;
    else if (strcmp("lognormal",name)==0) tmp.prtype=2;
    else printf("this prior not defined yet");
    
    get_doublesfrombrackets(in,tmp.par);
    
    return tmp;
}
/*************************************************************************/
int nextint(FILE *in)
{
    int ch;
    ch = skipspace(in);
    if (ch!=':')
	myerror("error integer should be preceded by a colon");
    fscanf(in,"%d",&ch);
    return ch;
}
/*************************************************************************/
parameters setup_parameters(const char *file)
{
    FILE *fd;
    parameters tmp;

    if (!(fd = fopen(file, "rb"))) {
	printf("unable to open input file\n");
	exit(EXIT_FAILURE);
    }
    if (findstart(fd,"datafile")) {
	if (!nextname(fd,tmp.datafilename))
	    myerror("error reading datafile name");
    }
    else {
	printf("unable to find filename: using default indat");
	strcpy(tmp.datafilename,"indat");
    }

    tmp.genetic_data=
	readintegermatrix(tmp.datafilename,&(tmp.samplesize),&(tmp.nloci));	
    if (findstart(fd,"samples")) tmp.reps=nextint(fd);
    else {
	printf("reps not found in parameter file %s, using 1000\n",file);
	tmp.reps=1000;
    }
    if (findstart(fd,"warmup")) tmp.warmup=nextint(fd);
    else {
	printf("warmup not found in parameter file %s, using 1000\n",file);
	tmp.warmup=1000;
    }
    if (findstart(fd,"Nbetsamp")) tmp.Nbetsamp=nextint(fd);
    else {
	tmp.Nbetsamp=10;
	printf("Nbetsamp not found in parameter file %s, using 10\n",file);
    }
    if (findstart(fd,"treebetN")) tmp.treebetN=nextint(fd);
    else {
	printf("treebetN not found in parameter file %s, using 10\n",file);
	tmp.treebetN=10;
    }
    if (findstart(fd,"seed")) tmp.seed=nextint(fd);
    else {
	printf("seed not found in parameter file %s, using 1\n",file);
	tmp.seed=1;
    }
    if (findstart(fd,"tuneN")) tmp.tuneN=nextdouble(fd);
    else  {
	printf("tuneN not found in parameter file %s, using 2000\n",file);
	tmp.tuneN=2000.;
    }
    if (findstart(fd,"tunemu")) tmp.tunemu=nextdouble(fd);
    else  {
	printf("tunemu not found in parameter file %s, using 0.001\n",file);
	tmp.tunemu=0.001;
    }
    if (findstart(fd,"badness")) tmp.badness=nextdouble(fd);
    else {
	printf("badness not found in parameter file %s, using 0.01\n",file);
	tmp.badness=0.01;
    }
    if (findstart(fd,"picgap")) tmp.picgap=nextint(fd);
    else {
	printf("no picgap in file, using default of 500");
	tmp.picgap=500;
    }
    if (findstart(fd,"muprior")) tmp.muprior= readprior(fd);
    else {
	printf("using default (non-informative) prior for mu");
	tmp.muprior.prtype=0;
    }
    if (findstart(fd,"Nprior")) tmp.Nprior= readprior(fd);
    else {
	printf("using default (non-informative) prior for N");
	tmp.Nprior.prtype=0;
    }
    
    return tmp;
}
/***************************************************************************/
void printpriors(FILE *out,parameters *any)
{
    fprintf(out,"\nPriors\n------\n");
    fprintf(out,"muprior: ");
    printpriortype(any->muprior,out);
    fprintf(out,"Nprior: ");
    printpriortype(any->Nprior,out);
    fprintf(out,"\n");
}
/***************************************************************************/
void printpardetails(parameters *any, FILE *out)
    
{ 
    fprintf(out,"\nTree Details\n============\n");
    fprintf(out,"%d microsatellite loci sampled from %d haplotypes,\n",
	    any->nloci,any->samplesize);
    fprintf(out,"read from datafile: %s\n",any->datafilename);
    fprintf(out,"\nAnalysis Details\n================\n");
    fprintf(out,"badness: %g\n",any->badness);
    fprintf(out,"seed: %d\n",any->seed);
    fprintf(out,"samples: %d\n",any->reps);
    fprintf(out,"warmup: %d \n",any->warmup);
    fprintf(out,"Nbetsamp: %d \n",any->Nbetsamp);
    fprintf(out,"treebetN: %d \n",any->treebetN);
    fprintf(out,"tunemu: %g \n",any->tunemu);
    fprintf(out,"tuneN: %g \n",any->tuneN);
    fprintf(out,"picgap: %d\n",any->picgap);
    printpriors(out,any);
}
/***********************************************************************/
void output_line(FILE *OUTFILE ,tree *any)
{
    fprintf(OUTFILE,"%g %g ",any->mu,any->N);
    any->totallength=calc_length(any->root);	
    fprintf(OUTFILE,"%g %g ",any->root->time,any->totallength);
    fprintf(OUTFILE,"\n");
}
/***********************************************************************/
void append_output_line(char *filename, tree *any)
{
    FILE *append;

    append=fopen(filename,"a");
    if (!append)
	myerror("error opening file for appending");
    fprintf(append,"\nline statistics\n\n");
    output_line(append,any);
    fclose(append);
}
/***********************************************************************/


