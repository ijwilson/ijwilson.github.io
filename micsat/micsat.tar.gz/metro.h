#ifndef METRO_H
#define METRO_H
#include "node.h"
#include "tree.h" 
int metro_mu(tree *any,double tune );
int metro_N(tree *any,double tune );
int metro_times(tree *any);
int metro_haplotype(tree *any);
#endif
