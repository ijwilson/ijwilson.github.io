#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "utils.h"
#include "random.h"


static unsigned int k,m,x,y,z,w,carry;
/******************************************************************/
void start_kiss(int seed)
{
     x=seed;y=102;z=12;w=34535;
     x = x * 69069 + 1;
     y ^= y << 13;
     y ^= y >> 17;
     y ^= y << 5;
     k = (z >> 2) + (w >> 3) + (carry >> 2);
     m = w + w + z + carry;
     z = w;
     w = m;
     carry = k >> 30;
}
/******************************************************************/
unsigned int kiss(void)
{
     x = x * 69069 + 1;
     y ^= y << 13;
     y ^= y >> 17;
     y ^= y << 5;
     k = (z >> 2) + (w >> 3) + (carry >> 2);
     m = w + w + z + carry;
     z = w;
     w = m;
     carry = k >> 30;
     return x+y+z;
}
/******************************************************************/
double dkiss(void)
{
    return ((double)kiss()+0.5)/4294967296.0;
}


int gen_from_p(double  *p, int n)
/* a routine to pick a number from 1 to n based on cumulative
probabilities in p    */
{
  double prob;
  int where;

  prob = ranDum();
  where = (int)prob*n+1;
  for (;;)
  {
    if  (prob <= p [where])
      {
    if (where==1) return 1;
    if (prob > p[where-1]) return where;
    else where--;
      }
    else
      {
    where++;
    if (where>=n) return n;
      }
  }
}


/**************************************************************/
int  gen_from_probs(double  *p, int n)
{
  double *cprob,sum=0.0;
  int where,i;
 
  cprob = dvector(0,n);
  cprob[0]=0.0;

  for (i=1;i<=n;i++) sum += p[i];
  if (sum <=0.0) return 0;
  for (i=1;i<=n;i++) cprob[i]=cprob[i-1]+p[i]/sum;
  
  where = gen_from_p(cprob,n);
  free_dvector(cprob,0,n); 
  return where;
 
}
/*************************************************************************/
double normal(void)

{
	static int iset = 0;
	static float gset;
	double  fac,rsq,v1,v2;

	if (iset == 0)
	{
		do
		{
			v1 = 2.0*ranDum( )-1.0;
			v2 = 2.0*ranDum( )-1.0;
			rsq = v1*v1+v2*v2;
		} while (rsq >= 1.0 || rsq == 0);

		fac = sqrt(-2.0*log(rsq)/rsq);

		gset = v1 * fac;
		iset = 1;
		return v2*fac;
	}
	else
	{
		iset = 0;
		return gset;
	}
}

