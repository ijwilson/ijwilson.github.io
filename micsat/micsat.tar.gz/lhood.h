#ifndef LIKELIHOOD_H
#define LIKELIHOOD_H 

#include "tree.h"

lltype loglikelihoodtheta(tree *thistree, double theta);
double  loglikelihoodtimes(tree * any);

double ll_mut(int *a,int *b, double time,double theta,int nloc);

#endif
