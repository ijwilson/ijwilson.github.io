// Time-stamp: <2006-10-19 10:28:14 rijw>
/** 
 * Simulate from the matrilineal pedigree model of selfing
 */ 
#include "mpforest.H"
#include "options.H"
#include <cstdio>
#include <iostream>
#include <string>


// generate a tree and write it to file
int main(int argc, char *argv[])
{
  int n,seed,T,N;
  double s;
  std::string stem,freqfile;
  options o("Options Used","0.5");
  try {
    o.add(&seed,"seed","Random number seed (positive integer)",1);
    o.add(&n,"n","Sample size",40);
    o.add(&s,"self","Selfing rate",0.9);
    o.add(&N,"N","population size",50);
    o.add(&T,"T","Time population existed (generations)",5);
    o.add(&stem,"stem","Stem for output files","out");
    o.add(&freqfile,"f","File name for frequency data","population.frequencies");
    o.readcommandline(argc,argv);
  }
  catch(std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 1;
  }
  catch (...) {
    std::cerr << "unknown exception";
    return EXIT_FAILURE;
  }

  rng r(seed);

  mpforest self(n,s,N,T,r);      // generate a tree

  std::ofstream ot(stemLeafFilename(stem,"tree").c_str());
  self.printTrees(ot,false,true);  
  ot.close();

  std::ofstream of(stemLeafFilename(stem,"partition").c_str());
  printvector(of,self.partition(-1),"\n");
  of.close();

  std::ofstream oM(stemLeafFilename(stem,"MROA").c_str());
  printvector(oM,self.partitionMROA(),"\n");
  oM.close();
  
  std::ifstream ipf(freqfile.c_str());
  popFreq pf(ipf);
  ipf.close();
  self.mutate(pf,r);

  std::ofstream od(stemLeafFilename(stem,"data").c_str());
  self.printGenotypes(od);
  od.close();
    
  std::ofstream opar(stemLeafFilename(stem,"pars").c_str());
  opar << o << std::endl;
  opar << pf;
  opar.close();

  return EXIT_SUCCESS;
}
