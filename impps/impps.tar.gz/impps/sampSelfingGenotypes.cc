#include "sampSelfingGenotypes.H"
#include "util.H"
#include <vector>

/** What is the probability of sampling the PeelVector a 
    with a selfing rate self from a background with  popFreq pf 
   This is from equation 37 from the paper                        */
double psample(double self,const PeelVector &a,const popFreq &pf)
{
  int loci=a.nloci();

  std::vector<double> x;
  std::vector<double> u;
  std::vector<double> v;
  
  for (int locus=0;locus<loci;locus++) {
     std::pair<double,double> b=a.UV(pf[locus],locus);
     
#ifdef VERYLOUD
     std::cerr << "UV returns pair " << 
       b.first << " " << b.second << std::endl; 
#endif
     if (b.second>b.first) {
       v.push_back(b.second);
       x.push_back(b.first/b.second);
     } else {
       u.push_back(b.first);
     }
  }
  int zeros=int(loci-v.size());

  // calculate the elementary symmetric functions
  e_sym_func e(x);

  double sm=0.0;//1./(1.-self/pow2(zeros)));   // note that e_0 = 1 by definition
  for (size_t i=0;i<=x.size();i++)
    sm += e(i)/(1.-self/pow2(i+zeros));

  
 
  // calculate the product of the V_js
  double pv = std::accumulate(v.begin(),v.end(),1.0,std::multiplies<double>());
  double pu = std::accumulate(u.begin(),u.end(),1.0,std::multiplies<double>());


  sm *= pv*pu*(1.-self);

  //
#ifdef VERYLOUD
  std::cerr << " pv = " << pv << "    pu = " << pu << std::endl;
  std::cerr << "Returning " << sm << std::endl;
#endif
  if (sm<=0.0) {
    std::cerr << "Error in psample with self=" << self << std::endl;
    std::cerr << " pv = " << pv << "    pu = " << pu << "  sm = " << sm << std::endl;
    for (size_t i=0;i<x.size();i++) 
      std::cerr << "i = " << i << " e_i = " << e(i) << std::endl;
    std::cerr << "zeros " << zeros << std::endl;
    std::cerr << a << std::endl << pf << std::endl;
    std::cerr << "u" << "\n";
    printvector(std::cerr,u,"\n");
    std::cerr << "v \n";
    printvector(std::cerr,v,"\n");
    std::cerr << "x \n";
    printvector(std::cerr,x,"\n");
    throw std::range_error("Error in psample - got a negative probability\n");
  }
  //  std::cerr << "sm = " << sm << "\n";
  return sm;
}
/** What is the probability of sampling the PeelVector a 
    with a selfing rate self from a background with  popFreq pf 
   This is from equation 37 from the paper                        */
std::vector<double> lpsample(const std::vector<double> &self,const PeelVector &a,const popFreq &pf)
{
  int loci=a.nloci();
  std::vector<double> x(loci),u(loci),v(loci);

  for (int locus=0;locus<loci;locus++) {
    std::pair<double,double> b=a.UV(pf[locus],locus);
    u[locus]=b.first;
    v[locus]=b.second;
    x[locus]=u[locus]/v[locus];
  }
  // calculate the elementary symmetric functions
  e_sym_func e(x);


  std::vector<double> sm(self.size());
  for (size_t i=0;i<self.size();i++) {
    sm[i]=1./(1.-self[i]);  
    for (int locus=1;locus<=loci;locus++) 
      sm[i] += e(locus)/(1.-self[i]/pow(2.0,locus));
  }
  // calculate the product of the V_js
  double pv=std::accumulate(v.begin(),v.end(),1.0,std::multiplies<double>()); 
  for (size_t i=0;i<sm.size();i++) sm[i] *= pv*(1.-self[i]);

  return sm;
}

// std::vector<double> lpsample(double self,const PeelVector &a,const popFreq &pf)
// {
//   int loci=a.nloci();
//   std::vector<double> x(loci),u(loci),v(loci);

//   for (int locus=0;locus<loci;locus++) {
//     std::pair<double,double> b=a.UV(pf[locus],locus);
//     u[locus]=b.first;
//     v[locus]=b.second;
//     x[locus]=u[locus]/v[locus];
//   }
//   // calculate the elementary symmetric functions
//   e_sym_func e(x);


//   double sm = 1/(1.-self) 
//   for (size_t i=0;i<self.size();i++) {
//     sm[i]=1./(1.-self[i]);  
//     for (int locus=1;locus<=loci;locus++) 
//       sm[i] += e(locus)/(1.-self[i]/pow(2.0,locus));
//   }
//   // calculate the product of the V_js
//   double pv=std::accumulate(v.begin(),v.end(),1.0,std::multiplies<double>()); 
//   for (size_t i=0;i<sm.size();i++) sm[i] *= pv*(1.-self);

//   return sm;
// }

