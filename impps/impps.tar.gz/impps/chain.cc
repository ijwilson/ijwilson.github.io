#include "chain.H"
/** Constructor for the chain                                        */
chain::chain(const std::vector<genotype> &gend,const popFreq &ppf,
	     ctsdistribution &sp, ctsdistribution &Np, int TT
	     , rng &rnd,double tuneN
	     ,double tunes,double startN, double starts)

  :gg(gend),perm(gg.size()),T(TT),pf(ppf),r(rnd),sPrior(sp),NPrior(Np),tune_N(tuneN),tune_s(tunes)
{
  for (size_t i=0;i<gg.size();i++) perm[i]=i;

  if (fabs(starts)<1E-6) s=sPrior.sample(r);
  else s=starts;

  if (NPrior.proper()&&startN==0)
    N=NPrior.sample(r);
  else if (startN>0) N=startN;
  else N=50;
  
 
  if (NPrior.isconstant()) N=NPrior.sample(r);
  if (sPrior.isconstant()) s=sPrior.sample(r);

  if (startN<gend.size()) N=gend.size();
 

  x = new mpforest(gg,s,int(N+0.5),T,pf,r);
}
/** And destructor                                                   */
chain::~chain()
{
    delete x;
}

bool chain::metro_sN() {
  if (sPrior.isconstant()) {
    return metro_N();
  } else if (NPrior.isconstant()) {
    return metro_s();
  }

  double news=reflect01(s+r.normal()*tune_s);
  double newN=reflect(x->minN(),N+r.normal()*tune_N);

  double acc=exp(
		 x->lprobtrees(news,newN,T)+sPrior.log_pdf(news)+NPrior.log_pdf(newN)
		 - x->lprobtrees(s,N,T)-sPrior.log_pdf(s)-NPrior.log_pdf(N)
		 );
  if (acc>1.0||r()<acc) {
    s=news;
     N=newN;
     return true;
   }
   return false;
 }
/** metropolis step for N                     */
bool chain::metro_N(bool logarithm)
 {
    if (NPrior.isconstant()) return false;
    double newN,lpdiff;

    if (logarithm) {
      newN=exp(log(N)+r.normal()*tune_N);
      lpdiff =  x->lprobtrees(s,newN,T)+NPrior.log_pdf(newN)
	- x->lprobtrees(s,N,T)-NPrior.log_pdf(N) + log(newN)-log(N);
    } else {
      newN=reflect(x->minN(),N+tune_N*r.normal());
      lpdiff =    x->lprobtrees(s,newN,T)+NPrior.log_pdf(newN)
	- x->lprobtrees(s,N,T)-NPrior.log_pdf(N);
    }
    double acc=exp(lpdiff);
    if (acc>1.0||r()<acc) {
      N=newN;
      return true;
    } 
    return false;
}
/** metroplois setp for the selfing rate s     */
bool chain::metro_s()
{
    if (sPrior.isconstant()) return false;
    double news=reflect01(s+tune_s*r.normal());
    double oldp =   x->peel(s,pf,false) +  x->lprobtrees(s,N,T) +  sPrior.log_pdf(news);
    double newp =   x->peel(news,pf,true) +  x->lprobtrees(news,N,T) + sPrior.log_pdf(s);
    double acc=exp(  newp-oldp		   );
    if (acc>1.0||r()<acc) {
      s=news;
      return true;
    }
    x->peel(news,pf,true);
    return false;
  }

/*
 * metropolis step on the population frequencies
 * through a random merge
 * of a pair of frequencies and then random reallocation of the
 * frequencies between the two classes
 *  Need to add some sort of support for a prior
 */
bool chain::metro_pf()
{
  double oldll=x->peel(s,pf,false);
  int locus=r.rint(pf.nloci());
  std::pair<int,int> ch=r.sample2int(pf.alleles(locus));
  double oldfirst=pf(locus,ch.first);
  double sm=oldfirst+pf(locus,ch.second);
  pf(locus,ch.first)=r()*sm;
  pf(locus,ch.second)=sm-pf(locus,ch.first);
  double acc=exp(x->peel(s,pf,true)-oldll);
  if (acc>1.0||r()<acc) {
    return true;
  } else {
    pf(locus,ch.first)=oldfirst;
    pf(locus,ch.second)=sm-oldfirst;
    x->peel(s,pf,true);
    return false;
  }
}
