#include "availableMap.H"
#include "mpforest.H"
#include "util.H"
#include "newio.H"
#include <sstream>


bool availInfo::sensible(const mpforest &mp) const {
  //  this->print(std::cerr);
    assert(generation_>0);
    assert(generation_<=mp.getT());
    assert(which_<int(mp.nleft(generation_-1)));
    assert(int(SH.to_ulong())<pow2(generation_));
    return true;
}

std::string printoutcrosses(int selfH, int gen) {
  std::ostringstream oss; 
  std::bitset<16> b(selfH),a;
   for (int i=0;i<gen;i++) {
     a[i]=b[gen-1-i];
     oss << a[i] << " ";
   }
   return oss.str();
}

std::bitset<16> outcrosses(int selfH, int gen) {
  std::bitset<16> b(selfH),a;
  for (int i=0;i<gen;i++) a[i]=b[gen-1-i];
  return a;
}

/** Construct the available map from an mpforest - 
    this depends on the number of samples left for each time    */
availableMap::availableMap(const mpforest &sf)
{
  int gen=sf.getT();
  cumsum.resize(gen+1);
  cumsum[0] =  pow2(gen);
  for (int i=1;i<=gen;i++) 
    cumsum[i] = cumsum[i-1] + sf.nleft(i-1)*pow2(i);

  //  printvector(std::cerr,cumsum,"\n");
  // allocate the memory
 
}


availInfo availableMap::get(int pos) 
{
  assert(pos<length());
  availInfo ret;
  //  std::cerr <<"\npos = "<<  pos << " out of " << length() << std::endl;
  //  printvector(std::cerr,cumsum,"\n");  
  if (pos<cumsum[0]) {  // in the first few samples - hence a new root
      ret.SelfHist(pos);
      ret.which(-1);
      ret.generation(cumsum.size()-1);
      //  ret.print(std::cerr,"returnin ret = ");
      return ret;
  }
  
  int gen;
  for (gen=1;gen<int(cumsum.size());gen++) {
    if (pos < cumsum[gen]) 	break;
  }
  assert(gen!=(int)cumsum.size());
  ret.generation(gen);
  pos -= cumsum[gen-1];
  int p2=pow2(gen);
  
  ret.which(pos/p2);
  ret.SelfHist(pos%p2);
  
  return ret;    
}
/** change an avialInfo into a position                                  */
int availableMap::pos(const availInfo &AI)
{
  //  AI.print(std::cerr,"In pos");
  int ret;
  if (AI.isroot()) {// i.e. not any of the current nodes
    ret = AI.SelfHist();
  } else {
    ret = cumsum[AI.generation()-1]+AI.which()*pow2(AI.generation())+AI.SelfHist();
  }
  if (ret >= length()) {
    std::cerr << "\n\nError\n"
	      << "ret " << ret << " " << length() << std::endl;
    AI.print(std::cerr,"error in pos with");
    printvector(std::cerr,cumsum,"\n");
  }
  assert(ret<length());
  return ret;
}

// int  availableMap::length(int nleft) {
  
//   return cumsum[cumsum.size()-1]+(nleft)*pow2(cumsum.size());
// }
