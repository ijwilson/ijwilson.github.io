// Time-stamp: <2006-11-07 13:02:00 uijw>
#include "probMap.H"
#include <iomanip>

/** Calculate the U and V coeficients based on Kevin's equations   */
std::pair<double,double> Peel::UV(const std::vector<double> &popf) const 
{
  assert((int)popf.size()==alleles());
  double u=0.0,v=0.0,tu=0.0;
  for (int i=0;i<alleles();i++) {
    // this is the new equation for v
    int start=alleles()*i;
    v += p_[start+i]*popf[i];
    tu +=  p_[start+i]*(1.-popf[i])*popf[i];
    for (int j=i+1;j<alleles();j++) u+=2.*p_[start+j]*popf[j]*popf[i];
    //  std::cerr << "partial u " << u << "  partial tu " << tu << std::endl;
  }
  
  return std::pair<double,double>(u-tu,v);
};
/** Add an outcrossed leaf with genotype g with popfreqs pf             */
void Peel::OutcrossLeaf(const char g[2],const std::vector<double> &freq) {

  assert(is_zero());
    if (g[0]==g[1]) {
      double add=0.5*freq[g[0]];
      for (int i=0;i<=g[0];i++) ordered_at(i,g[0]) += add;
      for (int i=g[0];i<alleles();i++) ordered_at(g[0],i) += add;
    } else {
      // g[1] is the allele that is outcrossed
      double add=0.5*freq[g[1]];
      for (int i=0;i<=g[0];i++) ordered_at(i,g[0]) += add;
      for (int i=g[0];i<alleles();i++) ordered_at(g[0],i) += add;
      // g[0] outcrossed
      add=0.5*freq[g[0]];
      for (int i=0;i<=g[1];i++) ordered_at(i,g[1]) += add;
      for (int i=g[1];i<alleles();i++) ordered_at(g[1],i) += add;
    }
  }
/** what are the probabilities for an outcrossed node with single descendent 
    with probabilities given by a      */
void Peel::OutcrossNode(const Peel &a,const std::vector<double> &freq ) {
    allocate(a.alleles_);
    assert(is_zero());
    // loop over the genotypes below
    for (int a1=0;a1<alleles();a1++) {
      // first consider the homozygotes
      if (a.ordered_at(a1,a1)>0.0) {  // does this contribute?
	for (int i=0;i<=a1;i++) ordered_at(i,a1) += a.ordered_at(a1,a1)*0.5*freq[a1];
	for (int i=a1;i<alleles();i++) ordered_at(a1,i) += a.ordered_at(a1,a1)*0.5*freq[a1];
      }
      for (int a2=a1+1;a2<alleles();a2++) {
	if (a.ordered_at(a1,a2)>0.0) {
	  // a2 added
	  double add=a.ordered_at(a1,a2)*0.5*freq[a2];
	  for (int i=0;i<=a1;i++) ordered_at(i,a1) +=  add;
	  for (int i=a1;i<alleles();i++) ordered_at(a1,i) +=  add;
	  // a1 added
	  add = a.ordered_at(a1,a2)*0.5*freq[a1];
	  for (int i=0;i<=a2;i++) ordered_at(i,a2) +=  add;
	  for (int i=a2;i<alleles();i++) ordered_at(a2,i) +=  add;
	}  
      }
    }
    //  a.print(std::cerr);
    // print(std::cerr);
  }
  /** what are the probabilities for a selfing node with single descendent 
      with probabilities given by a                                        */ 
void Peel::SelfingNode(const Peel &a) {
    allocate(a.alleles_);
    assert(is_zero());
    // loop through each of the pairs of descendent nodes
    for (int i=0;i<alleles();i++) {
      // first consider the heterozygous descendents
      for (int j=i+1;j<alleles();j++) {
	ordered_at(i,j) = 0.5*a.ordered_at(i,j);
      }
      // now consider homozygous descendents
      for (int j=0;j<i;j++) 
	ordered_at(j,i) += 0.25*a.ordered_at(i,i);
      assert(fabs(ordered_at(i,i))<1E-16);
      ordered_at(i,i) += a.ordered_at(i,i);    
      for (int j=i+1;j<alleles();j++) 
	ordered_at(i,j) += 0.25*a.ordered_at(i,i);
    }
  }
  /** Add a selfing leaf                                */
void Peel::SelfingLeaf(const char g[2]) 
{
 
  if (g[0]==g[1]) {
    for (int i=0;i<g[0];i++) 
      ordered_at(i,g[0])=0.25;
    ordered_at(g[0],g[0])=1.0;
    for (int i=g[0]+1;i<alleles();i++)
      ordered_at(g[0],i)=0.25;
  } else {
    at(g[0],g[1])=0.5;
  }
}
/** Is the second peel compatible at all                                 */
bool Peel::compatible(const Peel &p2) const {
  assert(p_.size()==p2.p_.size());
  std::vector<double>::const_iterator i=p_.begin(),j=p2.p_.begin();
  while (i!=p_.end()) {
    if (*i>0.0 && *j>0.0) return true;
    i++;j++;
  }
  return false;
}
/** print out the upper matrix of probabilities         */
std::ostream &Peel::print(std::ostream &o) const {
  assert(p_.size()>0);
  o << "     ";
  for (int i=0;i<alleles();i++) o << std::setw(12) << asAllele(i) << " ";
  o << std::endl;
  for (int i=0;i<alleles();i++) {
    o << asAllele(i) << "       ";
    for (int j=0;j<i;j++) o << "             ";
    for (int j=i;j<alleles();j++) o << std::setw(12) << p_[alleles()*i+j] << " ";
    o << std::endl;
  }
  return o;
};
/** Is the second peel compatible at all                                 */
bool Peel::equals(const Peel &p2) const {
  assert(p_.size()==p2.p_.size());
  std::vector<double>::const_iterator i=p_.begin(),j=p2.p_.begin();
  while (i!=p_.end()) {
    if (*i != *j) {
      std::cerr << "at position " << std::distance(p_.begin(),i) << " have " 
		<< *i << " and " << *j << std::endl;
      return false;
    }
    i++;j++;
  }
  return true;
}
/*****************************************************************************
 *
 *
 *
 *****************************************************************************/
 
  /** print out the vector of peeling probabilities           */
std::ostream &PeelVector::print(std::ostream &o) const  {
  assert(pv.size()>0);
  std::vector<Peel>::const_iterator i=pv.begin();
  while (i!=pv.end()) {
    i->print(o);
    o << std::endl;
    i++;
  }
  return o;
}
/**  print to an ostream           */
std::ostream &operator<<(std::ostream &o, const PeelVector &pv)
{
  return pv.print(o);
}
