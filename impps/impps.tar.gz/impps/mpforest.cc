// Time-stamp: <2006-11-07 13:27:55 uijw>

#include "util.H" // for pow2
#include "mpforest.H"
#include "sampSelfingGenotypes.H"
#include "availableMap.H"
#include <iterator> // for distance
#include <map>
#include <iomanip>

/** constructor without genotypes            */
mpforest::mpforest(int sampleSize,double self, int N,int T, rng &r)
  :available(T)
{
  sample.reserve(sampleSize);
  for (int i=0;i<sampleSize;i++) 
    sample.push_back( add_sample(i+1,self,N,T,r) );
  
  // Need to know the generations before to simulate real data
  genBefore.resize(nroots());
  for (int i=0;i<nroots();i++) 
    genBefore[i]=r.rgeometric(1.-self);
}
/** constructor                                                   */
mpforest::mpforest(const std::vector<genotype> &gg,double self, int N,int T
		   , const popFreq &pf,rng &r)
  :available(T)
{
  for (size_t i=0;i<gg.size();i++) {
    // std::cerr << "constucted " << i+1 << " N = " << N << std::endl;
    assert(check_trees(pf));
    snode *samp=new snode(gg[i],i+1);   
    
    std::vector<double> p = calculateP(samp->g,self,N,T,pf);
    int add=gen_from_p(p,r);
    availableMap am(*this);
    availInfo AF=am.get(add);
    snode *iii = insertsample(samp,AF);
    iii->recursive_peel(pf);
    assert(check_trees(pf));
  }
}
/** add a blank sample (with label lab)   */
snode *mpforest::add_sample(int lab, double s, int N, int T, rng &r)
{
  snode *leaf=new snode(lab);
  snode *prev=leaf,*curr=leaf;

  // loop through the times before T
  for (int time=0;time<T;time++) {
    // if there an outcross
    if (r()>s) { 
      prev->outcross=true; 
    }
    if (r()<double(nleft(time))/double(N)) { // a coalescence
      int which=r.rint(nleft(time));
      curr=available[time][which];
      curr->add(prev);
      return leaf;   // joined another mptree so stop;
    }  
    curr=new snode(time+1,prev);
    available[time].push_back(curr);
    ancestors.push_back(curr);
    prev=curr;
  }
  return leaf; 
}
/** insert a sample into the tree - returns the root of the tree
 * that has been changed (so that the likelihood of that tree can be recalculated  */
// TODO fix the probabilties
snode *mpforest::insertsample(snode *samp, const availInfo &a)
{
  //CHECKS 
  assert(a.sensible(*this));  
  snode *prev=samp,*curr=prev;

  samp->outcross=a.outcross(0,a.generation());

  // now have to create the rest of the history
   for (int Time=1;Time<a.generation();Time++) {
     curr=new snode(Time,prev);
     if (a.outcross(Time,a.generation())) {
       curr->outcross=true;
     } 
     available[Time-1].push_back(curr);
     ancestors.push_back(curr);
     prev=curr;
   }
  
  if (a.which()==-1) { // a new tree 
     curr=new snode(a.generation(),prev);
     available[a.generation()-1].push_back(curr);
     ancestors.push_back(curr);
      // TODO peel
     sample.push_back(samp);
    return curr;
  } else {
    curr=available[a.generation()-1][a.which()];
    curr->add(prev);
    // TODO fix the probabilities
    sample.push_back(samp);
    return curr->find_root();
  }
}
/**                                                                                              */
void mpforest::gibbs_sample(int T, double N, double self, const popFreq &pf, rng &r)
{     
#ifndef NDEBUG
  double oldll;
  oldll =  peel(self,pf) + lprobtrees(self,N,T);
#endif
 
  int which = r.rint(nsamples());
  snode *remove= sample[which];

  fixAvailable(remove);
  swaplast(which);  

  availInfo AF,AB;
  PeelVector pp=remove->find_root()->p;
  snode *ii= sample.back();
  snode *rt=remove_last_sample(AB);
  if (rt) rt->recursive_peel(pf);
  
  assert(check_trees(pf));

  std::vector<double> p = calculateP(ii->geno(),self,N,T,pf);
  
  int add=gen_from_p(p,r);  
  // add the node pointed to by which
  availableMap am(*this);
#ifndef NDEBUG
  int oldpos=am.pos(AB);
#endif

  assert(oldpos==am.pos(am.get(oldpos)));
  assert(int(p.size())==am.length());
  
  AF=am.get(add);
  snode *iii = insertsample(remove,AF);
  iii->recursive_peel(pf);
  assert(check_trees(pf));
 
#ifndef NDEBUG
    double diff = peel(self,pf,true) + lprobtrees(self,N,T) +log(p[oldpos]) - oldll - log( p[add]);
    if (fabs(diff)>1E-10) {
      std::cerr << "Difference  = " << diff << std::endl;
      std::cerr <<  peel(self,pf,true)<< " " 
		<< lprobtrees(self,N,T) << " " <<log(p[oldpos]) 
		<< " "<< oldll<< " " << log( p[add]) << std::endl;
      AB.print(std::cerr ," Back:");
      AF.print(std::cerr ," Forwards:");
      std::cerr << remove->g << std::endl <<  which  << std::endl;
      std::cerr << iii->p;
      std::cerr << pp;
      std::cerr << psample(self,pp,pf) << std::endl;
      printTrees(std::cerr,true,true,true);
   
      std::cerr << "positions forward:"  << add << " and backwards: " << oldpos << std::endl;
      for (size_t i=0;i<p.size();i++) {
	if (i%5==0) std::cerr << std::endl  << std::setw(4) << i << ": ";
	std::cerr << std::setw(14) << p[i] << " ";
      }
      std::cerr << std::endl;      
      assert( fabs(diff) < 1E-8 );
    }
#endif
}
/** Add a sample that has a genotype for a given selfing rate, T etc.        
 * returns the probability of the sample                             
 */
double mpforest::add_geno_sample(snode *samp,double self, double N, int T
				 , const popFreq &pf, rng &r) {
  
  // get the probability of the various places that this sample can be added
  std::vector<double> p = calculateP(samp->geno(),self,N,T,pf);
  //printvector(std::cerr,p,"\n");
  std::cerr << "maximum p = " << *(std::max_element(p.begin(),p.end())) <<
    " and sum = " << std::accumulate(p.begin(),p.end(),0.0) << std::endl;
  double psamp;
  int which=gen_from_p(p,r,psamp);  
  // add the node pointed to by which
  
  availableMap am(*this);
  availInfo aa=am.get(which);
  insertsample(samp,aa);
  //  sample.push_back(samp);

  return psamp;
}

/** Add a sample that has a genotype for a given selfing rate, T etc.        
 * returns the probability of the sample                             
 */
void mpforest::check_add(double self, double N, int T
				 , const popFreq &pf, rng &r) 
{ 
  availInfo AI;
  snode *samp=sample.back();
  remove_last_sample(AI);

#ifndef NDEBUG
    double oldllpeel=peel(self,pf,true);
#endif

  PeelVector pv(pf.alleles());
  pv.SelfingLeaf(samp->geno());
  PeelVector pv2(pf.alleles());
  pv2.OutcrossLeaf(samp->geno(),pf);

  availableMap am(*this);
  
  for (size_t j=0;j<nleft(0);j++) {
    assert( fabs(peel(self,pf,true)-oldllpeel)<1E-14);
    int count=pow2(T)+2*j;
    availInfo AP=am.get(count);
    double pj = available[0][j]->pjoin(self,pf,pv);
    if (pj>0.0) {
 
      insertsample(samp,AP);
      assert(fabs(oldllpeel + log(pj) -  peel(self,pf,true)) <1E-12);
     
      remove_last_sample(AP);
    }
    assert( fabs(peel(self,pf,true)-oldllpeel)<1E-14);
    AP=am.get(count+1);
    pj = available[0][j]->pjoin(self,pf,pv2);
    if (pj>0.0) {
      
      insertsample(samp,AP);
      assert(fabs(oldllpeel + log(pj) -  peel(self,pf,true) )<1E-12);
      remove_last_sample(AP);
    }
  }
  double oldll=peel(self,pf,true) + lprobtrees(self,N,T);

  // get the probability of the various places that this sample can be added
  std::vector<double> p = calculateP(samp->geno(),self,N,T,pf);

  for (int i=0;i<(int)p.size();i++) {
    if (p[i]>0) {
      assert(fabs(peel(self,pf,true) + lprobtrees(self,N,T)-oldll)<1E-10);
      
      availInfo aa=am.get(i),ab;
      assert(am.pos(aa)==i);
      insertsample(samp,aa);
      std::cout << i << " " << oldll + log(p[i]) << " " << peel(self,pf,true) + lprobtrees(self,N,T) << " " 
		<<  oldll + log(p[i]) -  peel(self,pf,true) - lprobtrees(self,N,T) <<  std::endl;
      remove_last_sample(ab);
      assert(am.pos(ab)==i);
    }
  }
}
/** remove the last sample                                                   
 * We assume that the available nodes are ordered so that we can just remove the 
 * last available node too
 * position give the position on the vector of probabilities thgat this would be placed
 * if it was added to create the same tree
 * returns the root of the removed node (if it is not removed), otherwise 0
 */
snode *mpforest::remove_last_sample(availInfo &AI)
{
  snode *curr=sample.back(),*rt;
  // keep track of the nodes to remove from the forest
  std::list<snode *> ancs;
  std::bitset<16> outcrosses;
  AI.reset();

  for (int Time=0;;Time++) {
    if (Time>0) {
      assert( Time-1 < int(available.size()));
      assert(curr->time()==Time);
      ancs.push_back(curr);
      assert(available[Time-1].size()>0);
      assert( available[Time-1].back()==curr);
      available[Time-1].pop_back();
    } 
    if (curr->up()==0) {  // a root
      AI.generation(Time);
      AI.which(-1);
      rt=0;
      break;
    }
    outcrosses[Time] = curr->outcross;
    if (curr->up()->ndesc()>1) {  // a coal
      curr->up()->erasedescendent(curr);
      // and fix the probability vectors up from this node
      curr->up()->fixProbVector();
      // where is curr->up() in available[Time+1] ?
      std::vector<snode *>::iterator ii=
	std::find( available[Time].begin(),available[Time].end(),curr->up());
      assert(ii!=available[Time].end());
      AI.which(std::distance(available[Time].begin(),ii));
      AI.generation(Time+1);
      rt=curr->find_root();
      break;
    }
    curr=curr->up();
  }
  //PRINT
  // std::cerr << "outcrosses: " << outcrosses << std::endl;
  AI.SelfHist(outcrosses);
  // now remove the ancestors
  std::for_each(ancs.begin(),ancs.end(),DeleteObject());
  removeanclist(ancs);

  // if (rt) {  //  repeel the altered bit of forest
  //   assert(rt->up()==0);
    // rt->peel();
  //  }

  sample.pop_back();
  assert(AI.sensible(*this));
  return rt;
}
/** print out the trees                                                                  */
std::ostream &mpforest::printTrees(std::ostream &o, bool printGenotypes,bool singletons
				   ,bool printSelfing)
{ 
  std::vector<snode *>::iterator i=rootbegin();
  while (i!=rootend()) {
    if (singletons&&(*i)->total_descendents()==1) {
      o << "'";
       (*i)->print_newick(o,printGenotypes,printSelfing);
       if (printSelfing) o << "=" << (*i)->selfstring() <<  "'" ;
       o <<  ":" << (*i)->time() << ";" << std::endl;
    } else if ((*i)->total_descendents()>1) {
      (*i)->print_newick(o,printGenotypes,printSelfing);
      if (printSelfing) o << "=" << (*i)->selfstring();
      o << ":" << (((*i)->ndesc()==1)?(*i)->descendent_[0]->nexttime():0) << ";" << std::endl;
    } 
    i++;
  }
  if (!singletons)  o << "# " << nroots() << " trees" << std::endl;
  return o;
}
/** print out the genotypes    
 *                                                                                */
std::ostream &mpforest::printGenotypes(std::ostream &o)
{
 std::vector<snode *>::iterator i=sample.begin();
  while (i!=sample.end()) {
    o << (*i)->g << std::endl;
    i++;
  }
  return o;
}
/** mutate the tree - returns the population frequencues used to draw the sample          */
popFreq mpforest::mutate(int loci, double theta,rng &r)
{
   std::vector<snode*>::iterator i=rootbegin();

  popFreq pf(loci,theta,r);
  
   while (i!=rootend()) {  
     (*i)->g=pf.sample(r);
  
    for (int count=0;count<genBefore[std::distance(rootbegin(),i)];count++) 
      (*i)->drift(r);

    (*i)->recurse_getgenotypes(pf,r);
    i++;
  }
  return pf;
}
/** mutate the tree - returns the population frequencues used to draw the sample          */
void mpforest::mutate(const popFreq &pf,rng &r)
{
  std::vector<snode*>::iterator i=rootbegin();
  while (i!=rootend()) {  
    (*i)->g=pf.sample(r);
  
    for (int count=0;count<genBefore[std::distance(rootbegin(),i)];count++) 
      (*i)->drift(r);

    (*i)->recurse_getgenotypes(pf,r);
    i++;
  }
}
/** Count the number of outcrosses                               */
int mpforest::countOutcrosses()
{
  int count=0;
  std::vector<snode *>::iterator i=sample.begin(),end=sample.end();
  while (i!=end) {
    if ((*i)->outcross) count++;
    i++;
  }
  i=ancestors.begin();
  end=ancestors.end();
  while (i!=end) {
    if ((*i)->outcross) count++;
    i++;
  }
  return count;
}
/** Peel the individual trees that lies below the *roots  */
double mpforest::peel(double self,const popFreq &pf,bool repeel) 
{
  double lp=0.0;
  itor i=rootbegin(),roote=rootend();
  while (i!=roote) {
    if (repeel) (*i)->recursive_peel(pf);
    lp +=  log(psample(self,(*i)->p,pf));
    i++;
  }
  return lp;
}

std::vector<genotype> mpforest::extractData() const 
{
  std::vector<genotype> x;
  citor i=sample.begin(),end=sample.end();
  while (i!=end) {
    x.push_back((*i)->geno());
    i++;
  }
  return x;
}

/** calculate the probabilities for adding a leaf anywhere in the matrilineal pedigree 
 *  The leaf can be added to any point of the already present forest or it may be 
 * a new tree in the forest                                                              
 *
 *  For a node in the tree at height t there are a total of 2^t different histories
 *
 *  The layout of the vector returned is
 *  p[0] - p[2^T-1] - the 2^T different histories that results in a new tree of order 1
 *  p[2^T] - [2^T + n_1*2] - the two histories for each node (in order node1 history1 node1 history2 node2 history1 .....)
 *
 */
std::vector<double> mpforest::calculateP(const genotype &g, double self, double N, int T
					 ,const popFreq &pf)
{
  std::vector<double> p(pow2(T));       // join at any ancestor or form a new tree  
  double Nround=floor(N+0.5);
  // I need to know the path of selfing and not selfing and the
  // resulting PeelVectors for each of these alternatives
  // 
  std::vector<PeelVector> current(pow2(T),pf.alleles()),last(pow2(T),pf.alleles());
  std::vector<double> pcurrent(pow2(T)),plast(pow2(T));
  //
  // now set up the first pair of outcrossing ProbVectors to 
  // be used for those adding at Time = 1 
  //
  current[0].SelfingLeaf(g);
  current[1].OutcrossLeaf(g,pf);
  pcurrent[0] = self;
  pcurrent[1] = 1.-self;
#ifdef LOUD  
  std::cerr << g << std::endl << pf << std::endl << current[0] << current[1];
#endif

  for (int Time=0;;Time++) {  // loop through the possible times
    int len=pow2(Time+1);
    // do the calculations for adding to the current tree
    for (size_t j=0;j<nleft(Time);j++) { 
      snode *cr=available[Time][j];
      // what is the probability of joining here ?
      // should do this all at once, but for now will do it 
      // the slow way, one at a time
      for (int k=0;k<len;k++) {
	p.push_back(
		    pcurrent[k]*cr->pjoin(self,pf,current[k])/Nround
		    );
      }      
    }
    if (Time==T-1) break;
    // get the next set of of probvectors (or the final ones)
    for (int i=0;i<len;i++) {
      last[i].copy(current[i]);
      //     assert(!last[i].is_zero(1E-10));
      plast[i] = pcurrent[i];
    }
    
    for (int i=0;i<len;i++) {
      current[2*i].SelfingNode(last[i]);
      pcurrent[2*i] = plast[i]*self*(1.-nleft(Time)/Nround);
      current[2*i+1].OutcrossNode(last[i],pf);
      pcurrent[2*i+1] = plast[i]*(1.-self)*(1.-nleft(Time)/Nround);
    } 
  }

  // now calculate the probabilities for the ordinary tree
  int p2=pow2(T);
  for (int i=0;i<p2;i++) {
    p[i] =  pcurrent[i]*(1.-nleft(T-1)/Nround)*psample(self,current[i],pf);
 
    //if (p[i]<=0) 
    //  std::cerr << current[i] << "pcurrent = " << pcurrent[i] 
    //		<< " N " << Nround << " nleft " << nleft(0)<< std::endl;;
    
    assert(
	   (pcurrent[i]>0.0&&p[i]>0.0)||pcurrent[i]==0.0
	   );   //these should never be zero
  }
 
 
  return p;
}

void mpforest::matchLast(int Tim, const std::vector<snode *> &lines)
{
  std::vector<snode *> &tomatch=available[Tim];

  size_t siz=lines.size();
  for (size_t i=0;i<siz;i++) {
    int pos=tomatch.size()-siz+i;
    std::vector<snode *>::iterator fi
      =std::find(tomatch.begin(),tomatch.end(),lines[i]);
    assert(fi!=tomatch.end());
    snode *tmp=tomatch[pos];
    tomatch[pos]=(*fi);
    (*fi)=tmp;
  }
#ifndef NDEBUG
  std::vector<snode *>::const_reverse_iterator r1=lines.rbegin();
  std::vector<snode *>::reverse_iterator r2=tomatch.rbegin();
  // std::cerr << "=======================================\n";
  while (r1!=lines.rend()) {
    //   std::cerr << *r1 << " " << *r2 << std::endl;
    assert((*r1)==(*r2));
    r1++;r2++;
  }
  //std::cerr << "=======================================\n";
#endif
  return;
}

/** Fix the available so that they are in the same order as
* tofix                                                   */
void mpforest::fixAvailable(const std::vector<snode *> &tofix)
{
  std::vector<snode *> current(tofix.begin(),tofix.end());
  std::map<snode *,int> count;
  int Tim=0;
  for (;;) {
    std::vector<snode *>::iterator i=current.begin(),end;
    while (i!=current.end()) {
      if ((*i)->up()==0) {
	i=current.erase(i);
      } else {
	(*i)=(*i)->up();
	i++;
      }
    }
    std::map<snode *,int> count;
    i=current.begin();
    end=current.end();
    while (i!=end) {
       if ((*i)->ndesc()>1) {
          if (count.find(*i)==count.end())
             count[(*i)]=1;
          else count[(*i)]+=1;
       }
       i++;
    }
    std::map<snode *,int>::iterator j=count.begin(),cend=count.end();
    while (j!=cend) {
      if (j->second!=int((j->first)->ndesc())) {
        assert(int((j->second)-int(j->first->ndesc())<0));
        // will never get rid of this node - erase from current
        current.erase(
                      std::remove(current.begin(),current.end(),j->first)
                      ,current.end()
		      );
      }
      j++;
    }
    keep_first_copy(current);
    if (current.size()==0) break;
    assert(current[0]->time()-1==Tim);
    matchLast(Tim,current);
    Tim+=1;
  }
  return;
}
/** Fix the available so that they are in the same order as
* tofix                                                   */
void mpforest::fixAvailable(snode *tofix)
{
  snode * current=tofix;

  for (int Tim=0;;Tim++) {
    if (current->up()->ndesc()>1) break;  // cannot be removed so keep
    current=current->up();
    if (current!=available[Tim].back()) {
      assert(std::find(available[Tim].begin(),available[Tim].end(),current)
	     != available[Tim].end());
      std::swap(*(std::find(available[Tim].begin(),available[Tim].end(),current))
		,available[Tim].back());
    }
    assert(current==available[Tim].back());
    assert(current->time()-1==Tim);
    if (current->up()==0) break;
  }
  return;
}
/** tesr that the available are in the same order as
* tofix                                                   */
void mpforest::testAvailable(snode *tofix)
{
  snode *current=tofix;
  int Tim=0;
  for (;;) {
    if (current->up()==0) break;
    if (current->up()->ndesc()>1) break;
    current=current->up();
    assert(available[Tim].back()==current);
    Tim+=1;
  }
  return;
}

double mpforest::lpselfing(double self) const
 {
  double logself=log(self);
  double log1ms=log(1.-self);
  
  int nout=0;
  citor ii=sample.begin(),end=sample.end();
  while (ii!=end) {
    if ((*ii)->outcross) nout++;
    ii++;
  }
  int n=(int)sample.size();
  double lp = (n-nout)*logself+nout*log1ms;
  
  size_t siz=available.size()-1;
  for (size_t i=0;i<siz;i++) {
    int nout=0;
    ii = available[i].begin();
    end= available[i].end();
    while (ii!=end) {
      if ((*ii)->outcross) nout++;
      ++ii;
    }
    lp += (nleft(i)-nout)*logself+nout*log1ms;
  }
  return lp;
}
/** What is the probability of the trees   
 * including the probability of selfing           */
double mpforest::lprobtrees(double s, double N, int T)
{
  double lp=0.0;
  double useN=floor(N+0.5);
  double lNfac=lgamma(useN+1.0);
  int nprev=sample.size();
  for (int i=0;i<T;i++) {
    lp += lNfac - lgamma(useN-nleft(i)+1) - (nprev)*log(useN);
    nprev=nleft(i);
  }
  return lp + lpselfing(s);
}


/** Check the trees    */
bool mpforest::check_trees(const popFreq &pf) const
{
  citor ii=rootbegin();
  while (ii!=rootend()) {
    if (!(*ii)->check(pf)) return false;
    ii++;
  }
  return true;
}
/**   */
void mpforest::removeNodesReverse(const std::vector<snode *> &NR, const popFreq &pf)
{
  std::vector<snode *>::const_reverse_iterator ri=NR.rbegin();
  while (ri != NR.rend()) {
    availInfo AB;
    assert(check_trees(pf));
    // testAvailable((*ri));
    snode *rt=remove_last_sample(AB);  
    if (rt) rt->recursive_peel(pf);
    assert(check_trees(pf));
    ri++;
  }
}

/**                                                                                              */
bool mpforest::metro_addremove_k(int kk,int T, double N, double self, const popFreq &pf, rng &r) 
{ 
     
  assert(check_trees(pf));
  
  double oldll = peel(self,pf,false) + lprobtrees(self,N,T);
 
  // now set up the last k samples in the correct order
  int start=sample.size()-kk;
  std::vector<snode *> NodesToRemove(sample.begin()+start,sample.end());

  double lpfor=0.0,lpback=0.0;  

  std::vector<availInfo> backwards;

  fixAvailable(NodesToRemove);  
  assert(check_trees(pf));

 
  std::vector<snode *>::reverse_iterator ri=NodesToRemove.rbegin();
  while (ri != NodesToRemove.rend()) {
    availInfo AB;
    assert(check_trees(pf));
    testAvailable((*ri));
    snode *rt=remove_last_sample(AB);  

    if (rt) rt->recursive_peel(pf);

    std::vector<double> p = calculateP((*ri)->geno(),self,N,T,pf);
    availableMap am(*this);
    int oldpos=am.pos(AB);
    lpback += log(p[oldpos]);
    lpback -= log(std::accumulate(p.begin(),p.end(),0.0));
    backwards.push_back(AB);
    assert(check_trees(pf));
    ri++;
  }

  bool failed=false;
  std::vector<snode *>::iterator fi=NodesToRemove.begin();
  while (fi!=NodesToRemove.end()) {
 
    std::vector<double> p = calculateP((*fi)->geno(),self,N,T,pf);
    double sm=std::accumulate(p.begin(),p.end(),0.0);
    if (sm<=0.0) {
      // really need to find a way to fix this!
      // want to rewind those added here and then procede add the initial
      // ones back - not completely straightforward
      failed=true;
      std::vector<snode *> NewNodesToRemove(NodesToRemove.begin(),fi);
      removeNodesReverse(NewNodesToRemove,pf);
      break;
      //throw std::domain_error("error sum of probabilities is zero in metro_addremove_k");
    } 
    int add=gen_from_p(p,r);  
    lpfor += log(p[add]);
    lpfor -= log(sm);
    availableMap am(*this);
    availInfo AF=am.get(add);
    snode *iii = insertsample((*fi),AF);
    iii->recursive_peel(pf);
    assert(check_trees(pf));
    fi++;
  }

  if (!failed) {
 
    double newll =  peel(self,pf,false) + lprobtrees(self,N,T);
    double x=exp(newll + lpback - oldll - lpfor);
    
    if (x>1.0||r()<x) {
      return true;
    } else {
      removeNodesReverse(NodesToRemove,pf);
    }
  }
  // and re-add the nodes that were removed
  fi=NodesToRemove.begin();
  std::vector<availInfo>::reverse_iterator ra=backwards.rbegin();
  while (fi!=NodesToRemove.end()) {    
    snode *iii = insertsample((*fi),(*ra));
    iii->recursive_peel(pf);
    ra++;fi++;
    assert(check_trees(pf));
  }
  assert(fabs(peel(self,pf,false) + lprobtrees(self,N,T) -oldll)<1E-8);
  return false;
}


/** Get the partition structure for a forest at generation gen        */
std::vector<int> mpforest::partition(int gen)
{
  assert(gen < (int)available.size());
  if (gen==-1) gen=available.size()-1; // roots
  std::vector<int> pt(nsamples());
  
  itor ii=sample.begin();
  while (ii!=sample.end()) {
    pt[(*ii)->label()-1] =  whichavailable((*ii)->up_n(gen+1),gen) + 1;
    ii++;
  }
  return pt;
}


std::vector<int> mpforest::partitionMROA()
{
  // first find the most recent outcrossed
  // ancestor for each sample - keep as a vector
  // using the label
  std::vector<int> pt(nsamples()); 
  int count=0;
  std::map<snode *,int> part;

  itor ii=sample.begin();
  while (ii!=sample.end()) {
    snode *mroa=  (*ii)->MROA();
    if (part.find(mroa)==part.end())
      part[mroa] = ++count;
    pt[(*ii)->label()-1] =  part[mroa];		  
    ii++;
  }

  return pt;
}
