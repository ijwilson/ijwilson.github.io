// Time-stamp: <2006-10-24 12:45:46 uijw>
// @file
#include "popFreq.H"
#include "genotype.H"
#include "newio.H"
#include <iomanip>   // for setw
#include <stdexcept>
#include <numeric>
#include "distributions.H"

/** Constuctor for a random set of population frequencies with the 
 * number of alleles given by nalleles                                 */
popFreq::popFreq(const std::vector<int> &nalleles,double a,rng &r):
  nloci_(nalleles.size())
  ,p_(nloci_),alleles_(nalleles)
{
  for (int locus=0;locus<nloci_;locus++) {
    p_[locus].resize(nalleles[locus]);
    alleles_[locus]=nalleles[locus];
    if (a>0.0)
      rdirichlet(&p_[locus][0],a,alleles_[locus],r);
    else 
      for (int j=0;j<alleles_[locus];j++) p_[locus][j]=1./alleles_[locus];
  }
}
/** Constuctor for a random set of population frequencies              */
popFreq::popFreq(int loci, double theta,rng &r):
  nloci_(loci),p_(loci),alleles_(loci)
{
  if (theta<0.0) {
    if (theta>-2.0) { 
      std::cerr << "If theta <0.0, needs to be <= -2\n";
      exit(EXIT_FAILURE);
    }
    alleles_.assign(loci,int(-theta));
    for (int locus=0;locus<nloci_;locus++) { 
      p_[locus].resize(alleles_[locus]);
      for (int j=0;j<alleles_[locus];j++) 
	p_[locus][j]=1./alleles_[locus];
    }
  } else {
    std::cerr << "Not written yet" << std::endl; exit(EXIT_FAILURE);
  }
}
/** Constructor for population frequencies from a vector of genotypes   
 - starts with all frequencies the same                              */
popFreq::popFreq(const std::vector<genotype> &d, bool addone)
  :nloci_(d[0].nloci()),p_(nloci_)
{
  alleles_=nalleles(d);
  //  printvector(std::cerr,alleles_);
  if (addone) 
    for (int locus=0;locus<nloci_;locus++)  alleles_[locus]+=1;

    for (int locus=0;locus<nloci_;locus++) 
      p_[locus].assign(alleles_[locus],1./(double(alleles_[locus])));  

}

popFreq::popFreq(const std::vector<genotype> &d, double a,rng &r)
  :nloci_(d[0].nloci()),p_(nloci_)
{
  alleles_=nalleles(d);
  for (int locus=0;locus<nloci_;locus++) { 
    p_[locus].resize(alleles_[locus]);
    rdirichlet(&p_[locus][0],a,alleles_[locus],r);
  }
}
/** draw a random haplotype from the population frequencies          */ 
std::vector<char> popFreq::haplotype(rng &r) const 
{
  std::vector<char> a(nloci());
  for (int locus=0;locus<nloci();locus++) 
    a[locus]=gen_from_p(p_[locus],r);
  return a;
}
/** sample a genotype from the population frequencies   */
genotype popFreq::sample(rng &r) const 
{
  assert(nloci()>0);
  
  genotype a(nloci());
  for (int locus=0;locus<nloci();locus++) {
    gen_from_p(a[locus],2,p_[locus],r);
  } 
  
 return a;
}

/** utility functions                                       */
std::ostream &operator<<(std::ostream &o, const popFreq &pf)
{
  o.width(7);
  o.precision(3);
  assert(pf.nloci()>0);
  for (int i=0;i<pf.nloci();i++) {
    for (int j=0;j<pf.alleles(i);j++) 
      o << std::setprecision(6) <<  std::setw(9) << pf(i,j) << " ";
    o << std::endl;
  }
  return o;
}

/** input from an input steam                                */
popFreq::popFreq(std::istream &in) 
{
   
  for (;;) { 
    int ch= skipspace(in);
    if (ch==EOF) break;
    else in.putback(ch);
    
    std::vector<double> a=readvec(in,'\n',1.0);
    if (a.size()>0) {
      p_.push_back(a);
      alleles_.push_back(a.size());
      double sm=std::accumulate(a.begin(),a.end(),0.0);
     
      if (fabs(sm-1.0) > 1E-8) 
	throw std::domain_error("error, sum of probabilities is not one in popFreq()");	     
    }
    else break;
  }
  nloci_=alleles_.size();
}

