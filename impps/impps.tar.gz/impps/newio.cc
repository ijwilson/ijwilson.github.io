#include "newio.H"

#include <stdexcept>
#include <sstream>


/** read a string from the input stream (ignoring comments) */
std::vector <std::string>
readstringline(std::istream &in,int suggestedlength,char until) {
    std::vector <std::string> data;
    data.reserve(suggestedlength);
    std::string x;
    int ch;

    for (;;) {
        ch = skipblank(in,until);
        if ((isdigit(ch))||isalpha(ch)||(ch=='-')||(ch=='+')||(ch=='(')) {
            in.putback(ch);
            in >> x;
            data.push_back(x);
        }
        else
            break;
    }
    return data;
}
/** read a "matrix" of strings separated by spaces from a file */
std::vector<std::vector<std::string> > readstringlines(std::istream &in) {
    std::vector<std::vector<std::string> > a;
    // check that this is not a commented out line
    int ch = skipblank(in,'\n');
    if (in.eof()) 
        return a;
    in.putback(ch);
    // read in a line
    std::vector<std::string> x= readstringline(in);
    int len=x.size();
    a.push_back(x);

    for(;;) {
        int ch = skipblank(in,'\n');
        if (ch==EOF)
            break;
        in.putback(ch);
        a.push_back(readstringline(in,len));
    }
    return a;
}
//
//
//
int skipblank(std::istream &in, char until) {
  static int ch;

  for (;;) {
    ch = in.get();
    if (ch=='#')
      ch = skipline(in);
    if (ch==until)
      return (ch);
    if (!isspace(ch))
      return (ch);
  }
}
//
//
//
bool skipto(std::istream &in, const char *pattern, const char comment) {
    int c;
    const char *p = pattern;

    if (in.eof())
        return false;
    while ((c = in.get()) != EOF) {
        if (*p == c)
            p++;
        else {
            if (comment == c)
                skipline(in);
            p = pattern;
        }
        if (!*p) {
            return true;
        }
    }
    return false;
}
//
//
//
int skipline(std::istream &in)
/*  a little function to read to the end of a line
    to remove comments !!                            */
{
    char tmp[2000];
    if (in.getline(tmp,2000)==NULL) {
        return EOF;
    }
    return '\n';
}
//
//
void checkreadcharacter(std::istream &in ,const char wh, const char *message) {
    int ch=skipblank(in);
    if (ch!=wh) {
        std::ostringstream oss;
        oss << message << " expected " << wh << ", got " << char(ch);
        throw std::domain_error(oss.str().c_str());
    }
}
//
//
//
std::vector <int> readintvector(std::istream &in,bool usechar, char until) {
    std::vector <int> data;
    int x;

    for (;;) {
      int ch = skipblank(in,until);
      //  std::cout << char(ch) << std::endl;
      if ((isdigit(ch))||(ch=='-')||(ch=='N')||(usechar&&isalpha(ch))) {
	if (ch=='N') { // check for NA
                int ch2 = in.get();
                if (ch2=='A')
                    x = -1;
                else {
                    if (!usechar)
                        throw std::domain_error("got 'N' in readintvector");
                    in.putback(ch2);
                }
            }
            else {
                in.putback(ch);
                in >> x;
            }
            data.push_back(x);
        }
        else
            break;
    }
    return data;
}

//
//
//
std::vector <std::vector<int> >
readcharintmat(std::istream &in,size_t &cols, bool usechar)
//  this reads a mixture of integer
{
    std::vector<std::vector<int> > a;
    for (;;) {
        int ch = skipblank(in,'\n');
	if (in.eof()) 
            break;
        else
            in.putback(ch);
        std::vector<int> x= readintvector(in,usechar,'\n');
        a.push_back(x);
    }
    if (a.size()>0) {
        cols=a[0].size();
        for (size_t i=1;i<a.size();i++) {
            if (a[i].size()!=cols)
                throw std::length_error("not a matrix in readcharintmatrix");
        }
    }
    return a;
}
// from http://oopweb.com/CPP/Documents/CPPHOWTO/Volume/C++Programming-HOWTO-7.html
// used as
// vector<string> tokens;
//    string str("Split me up! Word1 Word2 Word3.");
//    Tokenize(str, tokens);
//
void Tokenize(const std::string& str,
              std::vector<std::string>& tokens,
              const std::string& delimiters) {
    // Skip delimiters at beginning.
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    std::string::size_type pos     = str.find_first_of(delimiters, lastPos);
    while (std::string::npos != pos || std::string::npos != lastPos) {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}
//
//
//
std::vector<double> stringtodouble(std::vector<std::string> s,size_t from) {
    if (s.size()<from)
        std::domain_error("vector opf strings too short to convert");
    std::vector<double> x;
    x.reserve(s.size()-from);
    char *pEnd;
    for (size_t i=from;i<s.size();i++) {
        x.push_back(strtod(s[i].c_str(),&pEnd));
        if (*pEnd!='\0') {
            std::ostringstream oss;
            oss << "problem with string " << s[i] <<" in stringtodouble";
            throw std::domain_error(oss.str().c_str());
        }
    }
    return x;
}
/** get a value */

double getval(const std::string &str, const char *val, bool loud) {
    double v=-99.9;
    std::istringstream iss(str);
    if (!findparametername(iss,val)) {
        if (loud)
            std::cerr << val << " not found in string " << str << " in findparametername" << std::endl;
    }  else {
        char ch;
        iss >> ch;
        if (ch != '=')
            std::cerr << "expected = after " << val << " in string " << str << std::endl;

        iss >> v;
    }
    return v;
}
/*************************************************************************/
/*  function to get a string from keyboard - skipping
	all blanks in the input - suitable for getting file
	names for example.  If nothing is entered then
	def_val is used as a default                   */
/*************************************************************************/
std::string getstringfromkeyboard(const char *message,const  char *def_val) {
    std::cerr << "please enter " << message
    << ", or press <enter> for default (" << def_val << ")\n";

    std::string tmp;
    getline(std::cin,tmp);
    if (tmp.empty()) tmp=def_val;
    return tmp;

}
//
//  search the file for the first
// time that pattern appears, 1 if a success 0 otherwise
//
int findstart(std::istream &in,char *pattern) {
    int c;
    char *p = pattern,comment='#';

    if (in.eof())
        in.clear();     // if at end of file clear error
    in.seekg(0);                            // get back to start of file
    while ((c = in.get()) != EOF) {
        if (*p == c)
            p++;
        else {
            if (comment == c)
                skipline(in);
            p = pattern;
        }
        if (!*p)  return 1;
    }
    return 0;
}
//
//  skip spaces including line breaks
//
int skipspace(std::istream &in) {
    static int ch;

    for (;;) {
        ch=in.get();
        if (ch=='#')
            ch = skipline(in);
        if (!isspace(ch))
            return (ch);
    }
}
/****************************************************************/
char *readfromquotes(std::istream &in,int *len) {
    int ch = skipspace(in);
    if (ch!=39) {
        std::cerr << "error - should be a quote - ' is " << ch << "\n";
        exit(EXIT_FAILURE);
    }
    char *data = new char[1024];
    in.getline(data,1024,39);

    *len = 1024; // maybe alter this to realloc
    return data;
}
//
//
//
bool findparametername(std::istream &in, const char *pattern) {
    int c;
    const char *p = pattern,comment='#';

    if (in.eof())
        in.clear();     // if at end of file clear error
    in.seekg(0);				  // get back to start of file
    while ((c = in.get()) != EOF) {
        if (*p == c)
            p++;
        else {
            if (comment == c)
                skipline(in);
            p = pattern;
        }
        if (!*p) {
            if ((c=in.get()) == ':')
                return true;
            p=pattern;
        }
    }
    return false;
}
/** scan an integer vector after "namestring" from input file          */
std::vector<int> intvector_scan(std::istream &in, const char *namestring) {
    if (findparametername(in,namestring)) {
        return readintvector(in);
    } else {
        std::cerr << namestring
        << " not found in parameter file, using vector of length 0\n";
        return std::vector<int>(0);
    }
}
/***************************************************************************/
char *namescan(std::istream &in, char *namestring, char *default_val) {
    char *temp=NULL;

    if (findstart(in,namestring)) {
        temp = new char[201];
        if (!temp)
            throw ioerror("error allocating string in namescan\n");
        if (!nextname(in,temp))
            throw ioerror("error reading datafile name\n");
    }
    else if (default_val!=NULL) {
        std::cerr << namestring << " not found: using default "
        << default_val << std::endl;
        temp = new char[201];
        if (!temp) {
            std::cerr << "error allocating string in namescan";
            exit(EXIT_FAILURE);
        }
        strcpy(temp,default_val);
    }
    else {
        temp=NULL;
    }
    return temp;
}
/***************************************************************************/
int *charintvector_scan(std::istream &in, char *namestring,int *default_val,volume vol) {
    int *tmp;
    if (findstart(in,namestring)) {
        std::vector<int> a=readintvector(in);
        tmp=new int[a.size()+1];
        tmp[0]=a.size();
        for (size_t i=0;i<a.size();i++)
            tmp[i+1]=a[i];
        return tmp;
    }
    else {
        if (default_val==NULL) {
            if (vol==loud)
                std::cerr << namestring << " not found in parameter file, using NULL\n";
            tmp=NULL;
        }
        else {
            tmp=new int[2];
            tmp[0]=1;
            tmp[1]=*default_val;
            if (vol==loud)
                std::cerr << namestring << " not found in parameter file, using "
                << tmp[1] << std::endl;
        }
    }
    return tmp;
}
/*********************************************************************/
int nextname(std::istream &in, char *filename)
/*  filename must be at least 255 characters long */
{
    int ch;
    ch= skipspace(in);
    if (ch!=':')
        throw ioerror("expected a :");//ch= skipspace(in);
    in >> filename;

    //    for (i=0;i<255;i++) {
    //        if ((isspace(ch))||ch=='('||ch==EOF) {
    //
    //	  if (ch!=ungetc(ch,in))
    //	    throw "error putting back ch in nextname";
    //            filename[i]='\0';
    //            return 1;
    //        }
    //        filename[i]=(char)ch;
    //        ch = getc(in);
    //    }
    return 1;
}
/*********************************************************************/
int get_doublesfrombrackets(std::istream &in,double *par) {
    char ch;
    //    float f;

    ch=(char)skipspace(in);
    if (ch!='(') {
        par[0]=par[1]=0.0;
        return 0;
    }
    in >> par[0];
    ch=(char)skipspace(in);
    if (ch!=',') {
        par[1]=0.0;
        return 1;
    }
    in >> par[1];

    ch=(char)skipspace(in);
    if (ch==')')
        return 2;
    else {
        std::cerr << "only two parameters can be read in "
                << "getdoublesfrombrackets so far\n ";
        std::cerr << "read (" << par[0] << "," << par[1] << ch
        << "instead of (" << par[0] << "," << par[1] << ")";
        exit(EXIT_FAILURE);
        return  0;
    }
}

