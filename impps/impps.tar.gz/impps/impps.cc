// Time-stamp: <2006-11-07 11:53:33 uijw>
/** 
 * Simulate from the matrilineal pedigree model of selfing
 */ 
/* 0.98 - added a default.input file 
          and the logfile support                       */
#include "mpforest.H"
#include "options.H"
#include "gsl_distributions.H"
#include "chain.H"
#include "newio.H" 
#include "clock.H"

#include <cstdio>
#include <iostream>
// generate a tree and write it to file
int main(int argc, char *argv[])
{
  int seed,T,K;
  std::string spriorstring,Npriorstring,Tpriorstring;
  int replicates,burnin,between;
  double tuneN,tunes,starts,startN;
  std::string stem,freqfile,datafile,inputfile;
  bool logN;
  bool varf,metro_freq=false;
  options o("Options Used in mapafs","0.98");
  try {
    o.add(&seed,"seed","Random number seed (positive integer)",1);
    o.add(&burnin,"burnin","Burn in",100);
    o.add(&replicates,"reps","Replicates",1000);
    o.add(&between,"bet","gibbs steps between samples",20);
    o.add(&spriorstring,"self","Prior for s","uniform(0,1)");
    o.add(&Npriorstring,"N","Prior for N","positiveuniform");
    o.add(&T,"T","Time population existed (generations)",5);
    o.add(&stem,"stem","Stem for output files","res");
    o.add(&freqfile,"freq","File name for frequency data","");
    o.add(&varf,"varf","Variable Frequency Data?");
    o.add(&datafile,"d","File name for data file","out.data");
    o.add(&tuneN,"tuneN","Tuning parameter for N",10.0);
    o.add(&tunes,"tunes","Tuning parameter for s",0.2);
    o.add(&startN,"startN","starting value for N (0 for sample from prior)",0.0);
    o.add(&starts,"starts","starting value for s (0 for sample from prior)",0.0);
    o.add(&logN,"logN","logarithmic update for N?");
    o.add(&K,"k","Number to add and remove",5);
    o.add(&inputfile,"Input File","default.input");
    o.readcommandline(argc,argv);
    //if (inputfile!="")    
    o.readfromfile(inputfile.c_str());
    // and reread from the command line
    o.readcommandline(argc,argv);
  }
  catch(std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 1;
  }
  catch (...) {
    std::cerr << "unknown exception";
    return EXIT_FAILURE;
  }
  logger logfile(stemLeafFilename(stem,"log").c_str()); 
  std::ostringstream oss;
  oss << "Read options " << std::endl << o;
  logfile(oss.str().c_str());

  ctsdistribution *sprior;
  ctsdistribution *Nprior;

  try {
    std::istringstream iss(spriorstring);
    sprior=ctsdistributionparse(iss);
    iss.str(Npriorstring);
    Nprior=ctsdistributionparse(iss);
  }
  catch(std::exception& e) {
    logfile(e);
    return EXIT_FAILURE;
  }

  // read in the data files
  std::ifstream ifdata(datafile.c_str()); 
  std::vector<genotype> dd=readgenotypes(ifdata);
  ifdata.close();

  popFreq pf;

  if (freqfile!="") {
    std::ifstream ipf(freqfile.c_str());
    if (!ipf) {
      oss.clear();
      oss << " Error, frequency file " << freqfile << " not found, Exiting\n";
      logfile(oss.str().c_str());
      exit(EXIT_FAILURE);
    }
    if (!varf) {
      pf=popFreq(ipf);
    } else {
      // read the genotypes from the file
      std::vector<genotype> yy = readgenotypes(ifdata);
      // add genotypes from data - in case we are missing alleles
      yy.insert(yy.end(),dd.begin(),dd.end());
      pf = popFreq(yy,false);   
      metro_freq=true;
    }
    ipf.close();
  } else {
    if (!varf) {
      logfile("Sanity check failed:\nExpected variable frequencies if no population frequencies file given.\n"
	      "Please read the manual to look for the options needed, or try impps --help. Exiting\n\n");
      exit(EXIT_FAILURE);
    }
    metro_freq=true;
    pf = popFreq(dd,true); 
    //std::cerr << pf;
  }
  
 

#ifndef WIN32
  FILE *file = popen("uname -p","r");
  char procname[100];
  fgets(procname,99 , file);
#else
   char *procname = "unknown";
#endif
  //std::ifstream *stream = new std::ifstream(fileno(file)); 
  //logfile << "processor: " << procname << std::endl;

   oss.clear();
   oss << "\npopulation frequencies\n"
	  << "-----------------------------------------------------\n" << pf << "\n\n";
   logfile(oss.str().c_str());

   rng r(seed);
   
   std::ofstream out(stem.c_str());

  //for (size_t i=0;i<dd.size();i++) std::cerr << dd[i] << std::endl;

  chain c(dd,pf,*sprior,*Nprior,T,r,tuneN,tunes,startN,starts);
 
  success_rate success_s,success_N,success_k,success_pf;

  std::ofstream outpart(stemLeafFilename(stem,"partition").c_str());
  std::ofstream outMROA(stemLeafFilename(stem,"MROA").c_str());

  Clock mytime;

  try {
    progressBar pr(std::cout,"        Burning In: ",burnin);
    for (int j=0;j<burnin;j++) {
      pr.update(j);
      c.gibbs_reorder();
      for (int k=0;k<between;k++) c.gibbs();
      success_s += c.metro_s();
      success_N += c.metro_N(logN);
      success_k += c.metro_addremovek(K);
      if (metro_freq) success_pf += c.metro_pf();
    }  
    pr.restart("Collecting Samples: ",replicates);
    for (int j=0;j<replicates;j++) {
      pr.update(j);
      c.gibbs_reorder();
      for (int k=0;k<between;k++) c.gibbs();
      success_s += c.metro_s();
      success_N += c.metro_N(logN);
      success_k += c.metro_addremovek(K);
      if (metro_freq) success_pf += c.metro_pf();
      out << c.lposterior() << " " << c.s << " " << c.N 
	  << " " << c.nroots() << std::endl;
      // and output the partitions 
      printvector(outpart, c.rootpartition(),"\n");
      printvector(outMROA, c.MROApartition(),"\n"); 
    }
    pr.finish();
  }
  catch(std::exception& e) {
    logfile(e);
    return 1;
  }
  catch (...) {
    logfile("unknown exception");
    return EXIT_FAILURE;
  }

  oss.clear();
  oss  << "\n\nTime taken " << mytime.elapsed() << " seconds "
       << "on a " << procname << " processor" << std::endl;
  oss << o;
  oss << "success rate for updates " << std::endl  << "  add/remove " << K << ": "
	    << success_k() << "  s:" << success_s() << " "
	    << "  N: " << success_N();
  if (metro_freq)
    oss  <<  "  popfreq: "<< success_pf();
  oss  << std::endl;
  
  logfile(oss.str().c_str());
   
  return EXIT_SUCCESS;
}
