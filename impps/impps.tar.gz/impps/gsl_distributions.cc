#include <string>
#include <sstream>
#include <stdexcept>
#include <iostream>
#include "newio.H"
#include "gsl_distributions.H"
template <typename T> T readparfrombrackets(std::istream &in) ;

template <typename T1,typename T2>  
std::pair<T1,T2> readpairfrombrackets(std::istream &in) 
{
  std::pair<T1,T2> a;
  
  int ch = skipblank(in);

  if (ch != '(') 
    throw std::domain_error("expected a '(' in readpairfrombrackets");
  in >> a.first;
  
  ch = skipblank(in);
  if (ch != ',')   
    throw std::domain_error("expected a ',' in readpairfrombrackets");
  in >> a.second;
  
  ch = skipblank(in);
  if (ch != ')') 
    throw std::domain_error("expected a ')' to close brackets in readpairfrombrackets");
  
  return a;
}
template <typename T>
T readparfrombrackets(std::istream &in) 
{
  T a;
  
  int ch = skipblank(in);

  if (ch != '(') 
    throw std::domain_error("expected a '(' in readparfrombrackets");
  in >> a;
  
  ch = skipblank(in);
  
  if (ch != ')') 
    throw std::domain_error("expected a ')' to close brackets in readparfrombrackets");
  
  return a;
}

ctsdistribution *ctsdistributionparse(std::istream &is)
{
  is.clear();
  int ch = skipblank(is);
  
  if (ch==EOF)
    throw std::domain_error("no data in stream while parsing ctsdistribution");

  std::string name;
 
  if (isdigit(ch)) {  // reading a constant
    is.putback(ch);
    double x;
    is >> x;
    return new Constant(x);
  }
 
  is.putback(ch);
  for(;;) {
    ch = is.get();
    if (ch=='('||ch==EOF) break;
    name.push_back(ch);
  }

  is.putback(ch);
  if (name=="Improperuniform"||name=="improperuniform") {
    return new improperuniform();
  } else if (name=="positiveuniform"||name =="Positiveuniform") {
    return new improperuniform();
  } else if (name=="normal"||name=="Normal") {
    std::pair<double,double> a = readpairfrombrackets<double,double>(is);
    return new normal(a.first,a.second);
  }  else if (name=="Constant"||name=="constant") {
    double a = readparfrombrackets<double>(is);
    return new Constant(a);
  } else if (name=="Gamma"||name=="gamma") {
    std::pair<double,double> a = readpairfrombrackets<double,double>(is);
    return new Gamma(a.first,a.second);
  } else if (name=="Uniform"||name=="uniform") {
    std::pair<double,double> a = readpairfrombrackets<double,double>(is);
    return new uniform(a.first,a.second);
  } else if (name=="Beta"||name=="beta") {
    std::pair<double,double> a = readpairfrombrackets<double,double>(is);
    return new Beta(a.first,a.second);
  } else {
    std::ostringstream oss;
    oss << name << " not known as a distribution name in ctsdistributionparse" << std::endl; 
    throw std::domain_error(oss.str().c_str());
  }
}

ctsdistribution *fromstring(const std::string &s)
{
   std::istringstream a(s);
   return ctsdistributionparse(a);
}
