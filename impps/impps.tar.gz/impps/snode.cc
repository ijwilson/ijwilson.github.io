#include "snode.H"
#include "sampSelfingGenotypes.H"
#include <sstream>   // for ostringstream

/** returns a string that represents the selfing events along a node 
    (from the past to teh present undtil either a leaf or the next branchiong node      */
std::string snode::selfstring() 
{
  std::ostringstream oss;
  snode *a=this;

  oss <<  a->shortstatus();
    
  while (a->ndesc()==1) {
    a=a->descendent_[0];
    oss << "-" << a->shortstatus();
  }
  return oss.str();
}

/** print newick version below this node  */
std::ostream &snode::print_newick(std::ostream &o,bool printGenotype, bool printSelfing) 
{
  // need a node to move
  snode *a=this;
  // move it to an interesting node if needed
  while (a->ndesc()==1) a=a->descendent_[0];
  
  if (a->ndesc()==0) {
    assert(a->time_==0);
    assert(a->label_>=0);
    if (!printGenotype) {
      return o << a->label_;
    } else {
      o << "'" << a->geno() << "'";
    }
  } else  {
    o << "(";
    std::vector<snode *>::iterator i =a->descendent_.begin();
    while (true) {
      (*i)->print_newick(o,printGenotype);
      if (printSelfing) 
      	o << "=" << (*i)->selfstring();
      o << ":" << (*i)->nexttime();
      i++;
      if (i==a->descendent_.end()) break;
      else o << ",";
    }
    return o << ")";
  }
  return o;
}
/** recurse the genotypes - this assumes that the genotype
 * of this node has been set and itself sets the genotypes
 * of all descendent nodes                                   */
void snode::recurse_getgenotypes(const popFreq &pf,rng &r)
{
  std::vector<snode *>::iterator i=descendent_.begin();
  
  while (i!=descendent_.end()) {
    snode *current=(*i);
    current->g=g;
    if (current->outcross==true) {
      std::vector<char> male=pf.haplotype(r);
      for (size_t locus=0;locus<g.nloci();locus++) {
	if (r()<0.5) current->g(locus,0)=male[locus];
	else current->g(locus,1)=male[locus];
      }
    } else {
      for (size_t locus=0;locus<g.nloci();locus++) {
	double p=r();
	if (p<0.25) current->g.copy0(locus);
	else if (p<0.5) current->g.copy1(locus);
      }
    }
    current->recurse_getgenotypes(pf,r);
    i++;
  }
}
/** Recursively peel the tree lying below the current node    */
void snode::recursive_peel(const popFreq &pf)
{
  // std::cerr << "in recursive peel for " << pf.nloci() << " loci" <<  std::endl;
  p.allocate(pf.alleles(),0.0); 
  assert(pf.nloci()>0);

  if (descendent_.empty()) {        // advice from effective STL, use empty not size==0
    // This is a leaf node
    if (outcross) {
      p.OutcrossLeaf(g,pf); 
    } else { 
      p.SelfingLeaf(g);
    }
  } else {  // we are somewhere in the middle of the tree 
    // there is at least one descendent to recurse over so do it
    
    descendent_[0]->recursive_peel(pf);
    PeelVector a = descendent_[0]->p;
    
    itor i=descendent_.begin()+1; // already done the first
    while (i!=descendent_.end()) {
      (*i)->recursive_peel(pf);
      a.multiply((*i)->p);
      i++;
    }
    if (a.is_zero()) {
      std::cerr << "Should never be zero here\n";
      exit(EXIT_FAILURE);
    }
    if (up()==0) {
      p=a;
      return;
    }
    if (outcross) {
      p.OutcrossNode(a,pf);
    } else {   // selfing node so the simplest case
      p.SelfingNode(a);
    }    
  }
}
/** What is the probability that you can join the node (with PeelVector pv) to the 
 * forest in this location.  Works by peeling up the tree from here recalculating any
 * nodes that the added node affects (essentially all nodes above)
 * 
 * WARNING:  This function assumes that a peeling algorithm (with the correct selfing
 * rate has been performed on this tree
 */
double snode::pjoin(double self,const popFreq &pf,  const PeelVector &pv) 
{
  PeelVector tempp(pv);
  snode *curr=this;
  snode *desc=0;

  for (;;) { 
    itor ii=curr->descendent_.begin(),end=curr->descendent_.end();
    while (ii!=end) {
      if ((*ii)!=desc) {
	tempp.multiply((*ii)->p);
      }
      ii++;
    }
    if (tempp.is_zero()) return 0.0;
    if (curr->up()==0) {  
      double pn = psample(self,tempp,pf);
      double po = psample(self,curr->p,pf);
      return exp(log(pn)-log(po));
    }  
    PeelVector tmppb=tempp;
    if (curr->outcross) {
      tempp.OutcrossNode(tmppb,pf);
    } else {   // selfing node so the simplest case
      tempp.SelfingNode(tmppb);
    }
    desc=curr;
    curr=curr->up();
  }
}

/** A recursive function to fix the probability vector after a 
    node has been removed somewhere below the node  */
void snode::fixProbVector()
{
  assert(p.nloci()>0);
  
  p=descendent_[0]->p;
  itor i=descendent_.begin()+1; // already done the first
  while (i!=descendent_.end()) {
    p.multiply((*i)->p);
    i++;
  }
  if (up()==0) return;
  else up()->fixProbVector();
}


bool snode::check(const popFreq &pf ) const 
{

  PeelVector a;
  a.allocate(pf.alleles(),0.0); 
  
  if (descendent_.empty()) {        // advice from effective STL, use empty not size==0
    // This is a leaf node
    if (outcross) {
      a.OutcrossLeaf(g,pf); 
    } else { 
      a.SelfingLeaf(g);
    }
    if (!a.equals(p)) {
      std::cerr << "Problem with leaf " << label() << " in check\n";
      std::cerr << "p = " << p << " a = " << a; 
      return false;
    }
   
  } else { 
    if (!descendent_[0]->check(pf)) {
      std::cerr << "Fails checking descendent[0]\n";
      return false;
    }
    PeelVector b = descendent_[0]->p;
    assert(b.equals(descendent_[0]->p));
    citor i=descendent_.begin()+1; // already done the first
    while (i!=descendent_.end()) {
      (*i)->check(pf);
      b.multiply((*i)->p);
      i++;
    }
    if (up()==0) {
      if (!p.equals(b)) {
	std::cerr << "Problem with root " << this << " in check\n";
	std::cerr << "p = \n" << p << " a = \n" << a; 
	return false;
      }
      return true;
    }
    if (outcross) {
      a.OutcrossNode(b,pf);
    } else {   // selfing node so the simplest case
      a.SelfingNode(b);
    }    
  }
  if (!p.equals(a)) {
    std::cerr << "Problem with node " << this << " in check\n";
    std::cerr << "p = \n" << p << " a = \n" << a; 
    return false;
  }
  return true;
}
