/** Convert a sensible partition format to the format used by partitionview               
 * takes input from std:::cin and sends to std::cout      
 */

#include <vector>
#include <iostream>
#include <iterator>
#include <algorithm>

#include "newio.H"

int main() 
{

  /** first read in the input file                         */

 
  // read in the first line
  int dummy;
  std::vector< int > x = readvec(std::cin,'\n',dummy);
  int len=x.size();

  std::istream_iterator<int> eof;
  std::istream_iterator< int> in(std::cin);

  // now read in the rest
  std::copy( in, eof, std::back_inserter(x));

  if (x.size()%len!=0) {
    std::cerr << "Wrong number of input values\n";
    exit(EXIT_FAILURE);
  }

  // now print the first line of Kevin's format
  //   mc_datafile >> n_indivs >> k_max >> n_obs >> period >> u >> theta;

  int kmax = *(std::max_element(x.begin(),x.end()));
  int n=x.size()/len;
  std::cout << "Output from conv\n" 
	    << len << std::endl 
	    << kmax << std::endl
	    << n << std::endl
	    << "0\n1.0\n10.0\n";

  std::vector<int>::iterator ii=x.begin();
  int count=1;
  for (;;) {
    std::cout << count++ << std::endl << "-99.99\n";
    int groups=*(std::max_element(ii,ii+len));
    std::cout << groups << std::endl;
    for (int j=1;j<=groups;j++) {
      double cnt = std::count_if(ii,ii+len
				 ,std::bind2nd(std::equal_to<int>(),j) );
      std::cout << cnt << std::endl;
      std::vector<int>::iterator jj=ii;
      
      while(jj!=ii+len) {
	if (*(jj)==j) 
	  std::cout << std::distance(ii,jj) + 1 << " ";
	jj++;
      }
      std::cout << std::endl; 
    }

    ii+=len;
    if (ii==x.end()) break;
  }
  
}
