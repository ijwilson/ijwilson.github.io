#include "newtonI.H"
#include <iostream>
#include <cmath>

/** inline alternating function            */
inline int alt(int k) {
  return k%2==0?1:-1;
};


void e_sym_func::calc(const std::vector<double> &x)
{ 
  std::vector<double> p(m+1);
  std::vector<double> powers=x;
      
  p[0] = double(m);
  for (int k = 1; k <= m; k++) {
    p[k]=std::accumulate(powers.begin(),powers.end(),0.0);
    std::vector<double>::iterator powi=powers.begin();
    std::vector<double>::const_iterator xi=x.begin();
    while (powi!=powers.end()) *powi++ *= *xi++;
  }
      
  e_[0] = 1;
  for (int k = 1; k <= m; k++)     {
    double sum=0.0;
    for (int j = 0; j < k; j++)  sum += alt(k-j)*p[k-j]*e_[j];
    e_[k] = -sum/double(k);  
  }
}

/** Calculate using the logs of the x values - not tested   */
// void e_sym_func::calc_lx(const std::vector<double> &logx)
// { 
//   std::vector<double> p(m+1);
//   std::vector<double> logpowers=logx;
      
//   p[0] = double(m);
//   for (int k = 1; k <= m; k++) {
//     p[k]=0.0;
//     for (size_t ii=0;ii<logpowers.size();ii++) p[k] += exp(logpowers[ii]);
//     std::vector<double>::iterator lpowi=logpowers.begin();
//     std::vector<double>::const_iterator lxi=logx.begin();
//     while (lpowi!=logpowers.end()) *lpowi++ += *lxi++;
//   }
      
//   e_[0] = 1;
//   for (int k = 1; k <= m; k++)     {
//     double sum=0.0;
//     for (int j = 0; j < k; j++)  sum += alt(k-j)*p[k-j]*e_[j];
//     e_[k] = -sum/double(k);  
//   }
// }
