#include "options.H"
#include <iomanip> // for setw
#include <fstream>  // for ifstream
#include <sstream>  // for ostringstream

// from http://www.thescripts.com/forum/thread61719.html
std::string trimmed( std::string const& str, char const* sepSet )
{
  std::string::size_type const first = str.find_first_not_of(sepSet);
  return ( first==std::string::npos )
    ? std::string()
    : str.substr(first, str.find_last_not_of(sepSet)-first+1);
}

void Tokenise(const std::string& str,
                      std::vector<std::string>& tokens,
                      const std::string& delimiters)
// another copy of my tokenise function
{
    // Skip delimiters at beginning.
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    std::string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (std::string::npos != pos || std::string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}

void options::readcommandline(int argc, char *argv[]) {

  for (int i=1;i<argc;i++) {
    std::string a(argv[i]+2);
    if (a=="help") {
      printhelp(std::cout);
      exit(EXIT_SUCCESS);
    }
    if (a=="version") {
      printversion(std::cout,argv[0]);
      exit(EXIT_SUCCESS);
    }
  }
  pos_itor pi=posOpt.begin();
  for (int i=1;i<argc;i++) {
    if (argv[i][0]=='-') {
      if (argv[i][1]!='-') {
	std::ostringstream oss;
	oss <<  "Only using long style options" << std::endl;
	oss << argv[i] << " not recognised, exiting";
	throw options_exception(oss.str());
      }
      std::string a(argv[i]+2);
      
      // now split around "="
      std::vector<std::string> aa;
      Tokenise(a,aa,"=");
      if (aa.size()>2) throw options_exception("expected only one '=' in options!\n");
      
      itor i=optmap.find(aa[0].c_str());
      if (i==optmap.end()) {
	std::ostringstream oss;
	oss <<  "option --" << aa[0] << " not found";
	throw options_exception(oss.str());
      }
      if (aa.size()==1) {
	i->second->switchval();
      } else {
	i->second->read(aa[1]);
      }
    } else {
      (*pi)->read(argv[i]);
      pi++;
      //   std::ostringstream oss;
      //  oss << "I do not understand " << argv[i] << std::endl;
      //   oss << "positional options not supported yet";
      //   throw options_exception(oss.str());
    }
  }
}

/** read a set of options from a file                            
 * they are in the format that are written by writeoptions     
 * that is in pairs

option1 = value1v  #comment after line
option2 = value2
# this is a comment and everything on this line is ignored
               # spaces and a comment
*/
void options::readfromfile(const char *filename) 
{

  std::ifstream in(filename);
  if (!in) {
    // std::ostringstream oss;
    std::cerr << "Input file " << filename << " not found.  ";
    std::cerr << "Now trying command line options\n";
    return;
    //   throw options_exception(oss.str());
  }

  while (!in.eof())  {
    
    std::string line;
    getline(in,line);
    line=trimmed(line," \t");  // trim away leading and trailing spaces and tabs
    if (line[0]=='#') continue;  // is this line a comment

    std::vector<std::string> aa;
    Tokenise(line,aa,"#");        // use only before token
    if (aa.size()==0) continue;  // nothing here
    
    std::vector<std::string> bb;
    
    //   std::cerr << "tokenising " << aa[0] << std::endl;
    Tokenise(aa[0],bb,"=");
    if (bb.size()>2) throw options_exception("expected only one '=' per line!\n");
  
     // now throw away blank spaces and tabs at the ends of the strings 
    bb[0]=trimmed(bb[0]," \t");
    if (bb.size()==2) bb[1]=trimmed(bb[1]," \t");
      
    //  std::cerr << "finding " << bb[0] << std::endl;
    itor i=optmap.find(bb[0].c_str());
    if (i==optmap.end()) {
      std::ostringstream oss;
      oss <<  "option " << bb[0] << " not found";
      throw options_exception(oss.str());
    }
    //  std::cerr << i->first << std::endl;;
    if (bb.size()==1) {
      i->second->switchval();
    } else {
      i->second->read(bb[1]);
    }
  }
}

void options::printhelp(std::ostream &o)
{
  std::left(o);
   o << "Usage:\nfilename ";
  pos_itor pi=posOpt.begin();
  while (pi!=posOpt.end()) {
    o << "<positionOption" << std::distance(posOpt.begin(),pi)+1 << "> ";
    pi++;
  }
  o << "<Other Options>\n\n";
 o << description << std::endl;

 pi=posOpt.begin();
  while (pi!=posOpt.end()) {
    std::ostringstream oss;
    oss << " " << "positionOption" << std::distance(posOpt.begin(),pi)+1 << " ";
    (*pi)->print(oss,"(",")");
    o << std::setw(26) << oss.str();
    o << " ";
    (*pi)->printdesc(o);
    o << std::endl;
    pi++;
  }


  o << std::setw(26) << "  --help" << " produce help message " << std::endl; 
  o << std::setw(26) << "  --version" <<" version number" << std::endl;

  
  itor i=optmap.begin();
  while (i!=optmap.end()) {
    std::ostringstream oss;
    oss << "  --" << i->first << " ";
    i->second->print(oss,"(",")");
    o << std::setw(26) << oss.str();
    o << " ";
    i->second->printdesc(o);
    o << std::endl;
    i++;
  }

}



std::ostream &operator<<(std::ostream &o, const options &opt)
{
  opt.print(o);
  return o;
}
