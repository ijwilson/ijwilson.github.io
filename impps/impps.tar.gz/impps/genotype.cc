// Time-stamp: <2006-10-20 13:28:25 uijw>

#include "genotype.H"
#include "newio.H"
#include <set>

std::ostream &genotype::print(std::ostream &o) const {
    for (size_t i=0;i<data.size()/2;i++) {
      o << asAllele(data[2*i]) << "/" << asAllele(data[2*i+1]) << " ";
    }
    return o;
  };


std::ostream &operator<<(std::ostream &o, const genotype &g)
{
  return g.print(o);
}

std::vector<int> nalleles(const std::vector<genotype> &d)
{
  assert(d.size()>0);
  int loci=d[0].nloci();
  std::vector<int> nall(loci);
  for (int locus=0;locus<loci;locus++) {
    std::set<int> als;
    for (size_t i=0;i<d.size();i++) {
      const gtype *b=d[i][locus];
      if (als.find(b[0])==als.end()) als.insert(b[0]);
      if (als.find(b[1])==als.end()) als.insert(b[1]);
    }
    nall[locus]=als.size();
  }
  return nall;
}
/** Read genotypes from an input stream                  */
std::vector<genotype> readgenotypes(std::istream &o)
{
  std::vector<genotype> b;
  b.reserve(400);
  std::vector<std::string> a=readstringline(o);
  int nloci=a.size();
  //  std::cerr << "# " << nloci << " loci read";
  int count=1;
  b.push_back(convertStringsGenotypes(a,nloci));

  for (;;) {
    a=readstringline(o);
    if (a.size()==0) break;
    assert(int(a.size())==nloci);
    b.push_back(convertStringsGenotypes(a,nloci));
    count++;
  }
  //std::cerr << " and " << count << " lines\n";  
  return b;
}
/** convert strings of genotypes to genodata type             */
genotype convertStringsGenotypes(std::vector<std::string> &line,int loci)
{
  assert(int(line.size())==loci);
  genotype g(loci);
  for (int i=0;i<loci;i++) {
    g(i,0) =asInteger(line[i][0]);
    assert(line[i][1]=='/');
    g(i,1)=asInteger(line[i][2]);
  }
  return g;
}
